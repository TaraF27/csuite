import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

interface EmailRequest {
  to: string;
  advisor: {
    name: string;
    email: string;
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { to, advisor } = await req.json() as EmailRequest;

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(to)) {
      return new Response(
        JSON.stringify({ error: 'Invalid email format' }),
        { 
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Generate a unique form ID
    const formId = crypto.randomUUID();

    // Create the form URL
    const formUrl = `${Deno.env.get('PUBLIC_SITE_URL')}/prospect-form/${formId}`;

    // Email content
    const emailContent = `
      Hello,

      ${advisor.name} has invited you to complete a group benefits questionnaire. 
      This information will help us prepare an accurate quote for your organization.

      Please click the link below to access the secure form:
      ${formUrl}

      This link will expire in 7 days.

      If you have any questions, please contact ${advisor.name} directly at ${advisor.email}.

      Thank you,
      Chamber Plan Benefits Team
    `;

    // Send email using Supabase's built-in email service
    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Chamber Plan <no-reply@chamberplan.ca>',
        to: [to],
        subject: 'Complete Your Group Benefits Questionnaire',
        text: emailContent,
      }),
    });

    if (!emailResponse.ok) {
      throw new Error('Failed to send email');
    }

    return new Response(
      JSON.stringify({ success: true, formId }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Clock, Users, MapPin, FileText, Plus, X } from 'lucide-react';
import { DayPicker } from 'react-day-picker';
import * as Dialog from '@radix-ui/react-dialog';
import * as Popover from '@radix-ui/react-popover';
import * as Select from '@radix-ui/react-select';

interface Attendee {
  name: string;
  role: string;
  email: string;
}

interface MeetingDetails {
  date: Date;
  time: string;
  location: string;
  attendees: Attendee[];
  agenda: string[];
  documents: {
    name: string;
    type: string;
  }[];
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSchedule: (meeting: MeetingDetails) => void;
  defaultAttendees?: Attendee[];
}

const timeSlots = [
  '09:00 AM', '09:30 AM', '10:00 AM', '10:30 AM',
  '11:00 AM', '11:30 AM', '01:00 PM', '01:30 PM',
  '02:00 PM', '02:30 PM', '03:00 PM', '03:30 PM',
  '04:00 PM'
];

const locations = [
  'Chamber Office',
  'Virtual Meeting',
  'Advisor Office',
  'Custom Location'
];

export default function MeetingScheduler({ isOpen, onClose, onSchedule, defaultAttendees = [] }: Props) {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [customLocation, setCustomLocation] = useState<string>('');
  const [attendees, setAttendees] = useState<Attendee[]>(defaultAttendees);
  const [newAttendee, setNewAttendee] = useState<Attendee>({ name: '', role: '', email: '' });
  const [agenda, setAgenda] = useState<string[]>([
    'Review YTD performance',
    'Discuss member acquisition strategy',
    'Plan upcoming networking events',
    'Review benefit enhancements'
  ]);
  const [newAgendaItem, setNewAgendaItem] = useState<string>('');

  const handleSchedule = () => {
    if (!selectedDate || !selectedTime || !selectedLocation) return;

    const meeting: MeetingDetails = {
      date: selectedDate,
      time: selectedTime,
      location: selectedLocation === 'Custom Location' ? customLocation : selectedLocation,
      attendees,
      agenda,
      documents: []
    };

    onSchedule(meeting);
    onClose();
  };

  const handleAddAttendee = () => {
    if (newAttendee.name && newAttendee.role && newAttendee.email) {
      setAttendees([...attendees, newAttendee]);
      setNewAttendee({ name: '', role: '', email: '' });
    }
  };

  const handleRemoveAttendee = (index: number) => {
    setAttendees(attendees.filter((_, i) => i !== index));
  };

  const handleAddAgendaItem = () => {
    if (newAgendaItem) {
      setAgenda([...agenda, newAgendaItem]);
      setNewAgendaItem('');
    }
  };

  const handleRemoveAgendaItem = (index: number) => {
    setAgenda(agenda.filter((_, i) => i !== index));
  };

  return (
    <Dialog.Root open={isOpen} onOpenChange={onClose}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50" />
        <Dialog.Content className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex justify-between items-center mb-6">
            <Dialog.Title className="text-xl font-bold text-gray-900">
              Schedule Annual Partner Meeting
            </Dialog.Title>
            <Dialog.Close className="text-gray-400 hover:text-gray-600">
              <X className="h-6 w-6" />
            </Dialog.Close>
          </div>

          <div className="space-y-6">
            {/* Date and Time Selection */}
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Date
                </label>
                <Popover.Root>
                  <Popover.Trigger asChild>
                    <button className="w-full flex items-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                      <CalendarIcon className="h-5 w-5 text-gray-400 mr-2" />
                      {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
                    </button>
                  </Popover.Trigger>
                  <Popover.Portal>
                    <Popover.Content className="bg-white rounded-lg shadow-lg p-2 z-50">
                      <DayPicker
                        mode="single"
                        selected={selectedDate}
                        onSelect={setSelectedDate}
                        fromDate={new Date()}
                      />
                    </Popover.Content>
                  </Popover.Portal>
                </Popover.Root>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Select Time
                </label>
                <Select.Root value={selectedTime} onValueChange={setSelectedTime}>
                  <Select.Trigger className="w-full flex items-center justify-between px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-gray-400 mr-2" />
                      {selectedTime || 'Pick a time'}
                    </div>
                  </Select.Trigger>
                  <Select.Portal>
                    <Select.Content className="bg-white rounded-lg shadow-lg p-2 z-50">
                      <Select.Viewport>
                        {timeSlots.map((time) => (
                          <Select.Item
                            key={time}
                            value={time}
                            className="flex items-center px-4 py-2 hover:bg-gray-100 cursor-pointer"
                          >
                            <Select.ItemText>{time}</Select.ItemText>
                          </Select.Item>
                        ))}
                      </Select.Viewport>
                    </Select.Content>
                  </Select.Portal>
                </Select.Root>
              </div>
            </div>

            {/* Location Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Location
              </label>
              <Select.Root value={selectedLocation} onValueChange={setSelectedLocation}>
                <Select.Trigger className="w-full flex items-center justify-between px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 text-gray-400 mr-2" />
                    {selectedLocation || 'Select location'}
                  </div>
                </Select.Trigger>
                <Select.Portal>
                  <Select.Content className="bg-white rounded-lg shadow-lg p-2 z-50">
                    <Select.Viewport>
                      {locations.map((location) => (
                        <Select.Item
                          key={location}
                          value={location}
                          className="flex items-center px-4 py-2 hover:bg-gray-100 cursor-pointer"
                        >
                          <Select.ItemText>{location}</Select.ItemText>
                        </Select.Item>
                      ))}
                    </Select.Viewport>
                  </Select.Content>
                </Select.Portal>
              </Select.Root>
              {selectedLocation === 'Custom Location' && (
                <input
                  type="text"
                  value={customLocation}
                  onChange={(e) => setCustomLocation(e.target.value)}
                  placeholder="Enter location details"
                  className="mt-2 w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                />
              )}
            </div>

            {/* Attendees */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Attendees
              </label>
              <div className="space-y-4">
                {attendees.map((attendee, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-gray-900">{attendee.name}</p>
                      <p className="text-sm text-gray-500">
                        {attendee.role} • {attendee.email}
                      </p>
                    </div>
                    <button
                      onClick={() => handleRemoveAttendee(index)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                ))}
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newAttendee.name}
                    onChange={(e) => setNewAttendee({ ...newAttendee, name: e.target.value })}
                    placeholder="Name"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <input
                    type="text"
                    value={newAttendee.role}
                    onChange={(e) => setNewAttendee({ ...newAttendee, role: e.target.value })}
                    placeholder="Role"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <input
                    type="email"
                    value={newAttendee.email}
                    onChange={(e) => setNewAttendee({ ...newAttendee, email: e.target.value })}
                    placeholder="Email"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={handleAddAttendee}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Agenda */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Agenda
              </label>
              <div className="space-y-2">
                {agenda.map((item, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <span className="text-gray-900">{item}</span>
                    <button
                      onClick={() => handleRemoveAgendaItem(index)}
                      className="text-gray-400 hover:text-gray-600"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                ))}
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newAgendaItem}
                    onChange={(e) => setNewAgendaItem(e.target.value)}
                    placeholder="Add agenda item"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <button
                    onClick={handleAddAgendaItem}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Plus className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-3 mt-6">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSchedule}
              disabled={!selectedDate || !selectedTime || !selectedLocation}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Schedule Meeting
            </button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
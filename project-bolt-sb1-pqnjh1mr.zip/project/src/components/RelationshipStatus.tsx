import React from 'react';
import { TrendingUp, TrendingDown, AlertCircle, CheckCircle, Clock } from 'lucide-react';

interface Metric {
  name: string;
  value: number;
  trend: number;
  status: 'positive' | 'negative' | 'neutral';
}

interface Activity {
  type: string;
  date: string;
  description: string;
  status: 'completed' | 'pending' | 'overdue';
}

interface Props {
  metrics: {
    membershipGrowth: Metric;
    planParticipation: Metric;
    adminFees: Metric;
    memberRetention: Metric;
  };
  activities: Activity[];
  goals: {
    current: number;
    target: number;
    deadline: string;
  };
}

export default function RelationshipStatus({ metrics, activities, goals }: Props) {
  const formatPercent = (value: number) => {
    return `${value > 0 ? '+' : ''}${value.toFixed(1)}%`;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(value);
  };

  const getStatusColor = (status: 'positive' | 'negative' | 'neutral') => {
    switch (status) {
      case 'positive':
        return 'text-green-600';
      case 'negative':
        return 'text-red-600';
      default:
        return 'text-gray-600';
    }
  };

  const getActivityIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      case 'overdue':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-4">
        {Object.entries(metrics).map(([key, metric]) => (
          <div key={key} className="bg-white rounded-lg shadow-sm p-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">{metric.name}</span>
              <div className={`flex items-center ${getStatusColor(metric.status)}`}>
                {metric.trend > 0 ? (
                  <TrendingUp className="h-4 w-4 mr-1" />
                ) : (
                  <TrendingDown className="h-4 w-4 mr-1" />
                )}
                <span className="text-sm">{formatPercent(metric.trend)}</span>
              </div>
            </div>
            <p className="text-2xl font-bold text-gray-900 mt-2">
              {key === 'adminFees' ? formatCurrency(metric.value) : `${metric.value}%`}
            </p>
          </div>
        ))}
      </div>

      {/* Goals Progress */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Growth Goals</h3>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">
                Plan Participation Goal
              </span>
              <span className="text-sm text-gray-500">
                Target: {goals.target} members by {goals.deadline}
              </span>
            </div>
            <div className="relative pt-1">
              <div className="flex mb-2 items-center justify-between">
                <div>
                  <span className="text-xs font-semibold inline-block py-1 px-2 uppercase rounded-full text-blue-600 bg-blue-200">
                    {Math.round((goals.current / goals.target) * 100)}%
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-xs font-semibold inline-block text-blue-600">
                    {goals.current}/{goals.target}
                  </span>
                </div>
              </div>
              <div className="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                <div
                  style={{ width: `${(goals.current / goals.target) * 100}%` }}
                  className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activities */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div
              key={index}
              className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg"
            >
              {getActivityIcon(activity.status)}
              <div>
                <p className="text-sm font-medium text-gray-900">{activity.type}</p>
                <p className="text-sm text-gray-500">{activity.description}</p>
                <p className="text-xs text-gray-400 mt-1">{activity.date}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
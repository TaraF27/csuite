import React from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import { BriefcaseIcon, Bell, Users, FileText, BarChart3, MessageSquare, GraduationCap, Building2, Handshake, Clock } from 'lucide-react';
import Dashboard from './pages/Dashboard';
import CRM from './pages/CRM';
import ClientDetail from './pages/ClientDetail';
import EmployeesList from './pages/EmployeesList';
import EmployeeDetail from './pages/EmployeeDetail';
import Quotes from './pages/Quotes';
import QuoteDetail from './pages/QuoteDetail';
import QuotePresentation from './pages/QuotePresentation';
import Training from './pages/Training';
import Reports from './pages/Reports';
import ChamberRelations from './pages/ChamberRelations';
import LeadsAndReferrals from './pages/LeadsAndReferrals';

// Navigation items
const navigation = [
  { name: 'Dashboard', icon: BriefcaseIcon, path: '/' },
  { name: 'CRM', icon: Users, path: '/crm' },
  { name: 'Quotes', icon: FileText, path: '/quotes' },
  { name: 'Reports', icon: BarChart3, path: '/reports' },
  { name: 'Community', icon: MessageSquare, path: '/community' },
  { name: 'Training', icon: GraduationCap, path: '/training' },
  { name: 'Chamber Relations', icon: Building2, path: '/chamber-relations' },
  { name: 'Leads and Referrals', icon: Handshake, path: '/leads' },
  { name: 'Abeyance', icon: Clock, path: '/abeyance' },
];

function Layout() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 h-full w-64 bg-white shadow-lg">
        <div className="px-6 py-8">
          <h1 className="text-2xl font-bold text-blue-900">C-Suite</h1>
          <div className="mt-8 space-y-2">
            {navigation.map((item) => (
              <button
                key={item.name}
                onClick={() => navigate(item.path)}
                className="flex items-center w-full px-4 py-2 text-gray-600 hover:bg-blue-50 hover:text-blue-900 rounded-lg transition-colors"
              >
                <item.icon className="w-5 h-5 mr-3" />
                {item.name}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="ml-64 min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm">
          <div className="flex justify-between items-center px-8 py-4">
            <h2 className="text-2xl font-semibold text-gray-900">Welcome back, Sarah</h2>
            <button className="relative p-2 text-gray-400 hover:text-gray-500">
              <Bell className="w-6 h-6" />
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
            </button>
          </div>
        </header>
        <div className="p-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/crm" element={<CRM />} />
            <Route path="/crm/client/:id" element={<ClientDetail />} />
            <Route path="/crm/client/:clientId/employees" element={<EmployeesList />} />
            <Route path="/crm/client/:clientId/employees/:employeeId" element={<EmployeeDetail />} />
            <Route path="/quotes" element={<Quotes />} />
            <Route path="/quotes/:id" element={<QuoteDetail />} />
            <Route path="/quotes/:id/presentation" element={<QuotePresentation />} />
            <Route path="/training" element={<Training />} />
            <Route path="/reports" element={<Reports />} />
            <Route path="/chamber-relations" element={<ChamberRelations />} />
            <Route path="/leads" element={<LeadsAndReferrals />} />
            <Route path="*" element={<div>Page coming soon...</div>} />
          </Routes>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Layout />
    </Router>
  );
}

export default App;
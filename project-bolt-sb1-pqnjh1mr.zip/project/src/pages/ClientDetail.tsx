import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Phone, Mail, Building, Calendar, Users, FileText, ArrowUpRight, Clock, CheckCircle, AlertCircle } from 'lucide-react';

// Mock client data - in a real app, this would come from an API
const clientData = {
  id: 1,
  name: 'Tech Solutions Inc.',
  contact: 'John Smith',
  email: 'john@techsolutions.com',
  phone: '(555) 123-4567',
  type: 'Technology',
  employees: 45,
  renewalDate: '2024-08-15',
  status: 'Active',
  planType: 'Extended Health & Dental',
  address: '123 Tech Avenue, Silicon Valley, CA 94025',
  yearJoined: 2020,
  notes: 'Client interested in expanding coverage for mental health benefits.',
  recentActivity: [
    {
      id: 1,
      type: 'Quote',
      description: 'Dental plan upgrade quote requested',
      date: '2024-03-15',
      status: 'Pending'
    },
    {
      id: 2,
      type: 'Meeting',
      description: 'Annual benefits review completed',
      date: '2024-03-10',
      status: 'Completed'
    },
    {
      id: 3,
      type: 'Update',
      description: 'Employee count updated from 42 to 45',
      date: '2024-03-05',
      status: 'Completed'
    }
  ],
  upcomingEvents: [
    {
      id: 1,
      type: 'Renewal',
      description: 'Benefits plan renewal',
      date: '2024-08-15'
    },
    {
      id: 2,
      type: 'Meeting',
      description: 'Q2 Review Meeting',
      date: '2024-06-01'
    }
  ]
};

export default function ClientDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      {/* Client Header */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-4">
            <div className="h-16 w-16 bg-blue-100 rounded-full flex items-center justify-center">
              <Building className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{clientData.name}</h1>
              <p className="text-gray-500">{clientData.type} • Member since {clientData.yearJoined}</p>
            </div>
          </div>
          <div className="flex space-x-3">
            <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-sm font-medium text-gray-700">
              Edit Details
            </button>
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium">
              Create Quote
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Contact Information */}
        <div className="col-span-1 bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Users className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{clientData.contact}</p>
                <p className="text-sm text-gray-500">Primary Contact</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{clientData.email}</p>
                <p className="text-sm text-gray-500">Email</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{clientData.phone}</p>
                <p className="text-sm text-gray-500">Phone</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Building className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{clientData.address}</p>
                <p className="text-sm text-gray-500">Address</p>
              </div>
            </div>
          </div>
        </div>

        {/* Plan Details */}
        <div className="col-span-2 bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Plan Details</h2>
          <div className="grid grid-cols-3 gap-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <FileText className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-sm font-medium text-gray-900">{clientData.planType}</p>
              <p className="text-sm text-gray-500">Current Plan</p>
            </div>
            <div 
              className="p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors"
              onClick={() => navigate(`/crm/client/${id}/employees`)}
            >
              <Users className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-sm font-medium text-gray-900">{clientData.employees}</p>
              <p className="text-sm text-gray-500">Employees</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <Calendar className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-sm font-medium text-gray-900">{new Date(clientData.renewalDate).toLocaleDateString()}</p>
              <p className="text-sm text-gray-500">Renewal Date</p>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity & Upcoming Events */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {clientData.recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className={`mt-1 ${
                  activity.status === 'Completed' ? 'text-green-500' : 'text-yellow-500'
                }`}>
                  {activity.status === 'Completed' ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : (
                    <Clock className="h-5 w-5" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{activity.description}</p>
                  <p className="text-sm text-gray-500">{activity.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h2>
          <div className="space-y-4">
            {clientData.upcomingEvents.map((event) => (
              <div key={event.id} className="flex items-start space-x-3">
                <Calendar className="h-5 w-5 text-gray-400 mt-1" />
                <div>
                  <p className="text-sm font-medium text-gray-900">{event.description}</p>
                  <p className="text-sm text-gray-500">{event.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Notes Section */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Notes</h2>
        <p className="text-sm text-gray-600">{clientData.notes}</p>
      </div>
    </div>
  );
}
import React, { useState } from 'react';
import { BarChart3, PieChart, TrendingUp, Users, FileText, Calendar, Download, Filter, RefreshCw, ArrowUp, ArrowDown, DollarSign, Briefcase, Building2, Shield } from 'lucide-react';

// Mock data for reports
const revenueData = {
  total: 1250000,
  growth: 15.8,
  monthly: [
    { month: 'Jan', value: 98000 },
    { month: 'Feb', value: 102000 },
    { month: 'Mar', value: 105000 },
    { month: 'Apr', value: 108000 },
    { month: 'May', value: 112000 },
    { month: 'Jun', value: 115000 },
  ]
};

const clientMetrics = {
  total: 156,
  active: 142,
  pending: 8,
  atRisk: 6,
  byIndustry: [
    { industry: 'Technology', count: 45, growth: 12 },
    { industry: 'Manufacturing', count: 32, growth: 8 },
    { industry: 'Healthcare', count: 28, growth: 15 },
    { industry: 'Retail', count: 25, growth: -2 },
    { industry: 'Professional Services', count: 18, growth: 5 },
    { industry: 'Others', count: 8, growth: 0 }
  ]
};

const renewalMetrics = {
  upcoming: 12,
  completed: 24,
  retention: 95,
  nextRenewals: [
    { client: 'Tech Solutions Inc.', date: '2024-05-15', employees: 45, premium: 125000 },
    { client: 'Global Manufacturing', date: '2024-05-22', employees: 78, premium: 215000 },
    { client: 'Healthcare Plus', date: '2024-06-01', employees: 120, premium: 350000 },
    { client: 'Retail Corp', date: '2024-06-15', employees: 55, premium: 165000 }
  ]
};

const planMetrics = {
  totalEmployees: 3450,
  averagePremium: 325,
  topPlans: [
    { name: 'Enhanced Health & Dental', clients: 45, employees: 1200 },
    { name: 'Standard Plus', clients: 38, employees: 950 },
    { name: 'Basic Coverage', clients: 52, employees: 850 },
    { name: 'Premium Package', clients: 21, employees: 450 }
  ],
  benefitUtilization: [
    { benefit: 'Prescription Drugs', utilization: 78 },
    { benefit: 'Dental Services', utilization: 65 },
    { benefit: 'Paramedical', utilization: 45 },
    { benefit: 'Vision Care', utilization: 35 },
    { benefit: 'Mental Health', utilization: 25 }
  ]
};

export default function Reports() {
  const [dateRange, setDateRange] = useState('last6Months');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleRefresh = () => {
    setIsRefreshing(true);
    // Simulate data refresh
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-500">Track your performance and business metrics</p>
        </div>
        <div className="flex items-center space-x-4">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="rounded-lg border-gray-300 text-gray-700"
          >
            <option value="last3Months">Last 3 Months</option>
            <option value="last6Months">Last 6 Months</option>
            <option value="lastYear">Last Year</option>
            <option value="ytd">Year to Date</option>
          </select>
          <button
            onClick={handleRefresh}
            className={`p-2 text-gray-500 hover:text-gray-700 rounded-lg ${isRefreshing ? 'animate-spin' : ''}`}
          >
            <RefreshCw className="h-5 w-5" />
          </button>
          <button className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-600">
            <Download className="h-5 w-5 mr-2" />
            Export
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-blue-600" />
            </div>
            <span className={`flex items-center text-sm ${revenueData.growth > 0 ? 'text-green-600' : 'text-red-600'}`}>
              {revenueData.growth > 0 ? <ArrowUp className="h-4 w-4 mr-1" /> : <ArrowDown className="h-4 w-4 mr-1" />}
              {revenueData.growth}%
            </span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mt-4">{formatCurrency(revenueData.total)}</h3>
          <p className="text-gray-500">Total Premium Revenue</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Building2 className="h-6 w-6 text-green-600" />
            </div>
            <span className="text-sm text-gray-500">{clientMetrics.active} Active</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mt-4">{clientMetrics.total}</h3>
          <p className="text-gray-500">Total Clients</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Users className="h-6 w-6 text-purple-600" />
            </div>
            <span className="text-sm text-gray-500">{formatCurrency(planMetrics.averagePremium)}/employee</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mt-4">{planMetrics.totalEmployees}</h3>
          <p className="text-gray-500">Total Employees Covered</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Shield className="h-6 w-6 text-yellow-600" />
            </div>
            <span className="text-sm text-gray-500">{renewalMetrics.upcoming} Upcoming</span>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mt-4">{renewalMetrics.retention}%</h3>
          <p className="text-gray-500">Client Retention Rate</p>
        </div>
      </div>

      {/* Revenue Chart & Client Distribution */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Revenue Trend</h3>
            <button className="text-gray-400 hover:text-gray-600">
              <Filter className="h-5 w-5" />
            </button>
          </div>
          <div className="h-64 flex items-end justify-between space-x-2">
            {revenueData.monthly.map((month) => (
              <div key={month.month} className="flex-1">
                <div
                  className="bg-blue-500 rounded-t-lg hover:bg-blue-600 transition-colors cursor-pointer"
                  style={{ height: `${(month.value / 120000) * 100}%` }}
                  title={`${month.month}: ${formatCurrency(month.value)}`}
                />
                <div className="text-xs text-gray-500 text-center mt-2">{month.month}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-semibold text-gray-900">Clients by Industry</h3>
            <button className="text-gray-400 hover:text-gray-600">
              <Filter className="h-5 w-5" />
            </button>
          </div>
          <div className="space-y-4">
            {clientMetrics.byIndustry.map((industry) => (
              <div key={industry.industry}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-gray-600">{industry.industry}</span>
                  <span className="text-sm font-medium text-gray-900">{industry.count}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${(industry.count / clientMetrics.total) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Upcoming Renewals */}
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold text-gray-900">Upcoming Renewals</h3>
            <button className="text-sm text-blue-600 hover:text-blue-700">View All</button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Client</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Renewal Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employees</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Premium</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {renewalMetrics.nextRenewals.map((renewal) => (
                <tr key={renewal.client} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{renewal.client}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">{formatDate(renewal.date)}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{renewal.employees}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{formatCurrency(renewal.premium)}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Plan Analytics */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Top Plan Types</h3>
          <div className="space-y-4">
            {planMetrics.topPlans.map((plan) => (
              <div key={plan.name} className="flex items-center">
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-gray-900">{plan.name}</span>
                    <span className="text-sm text-gray-500">{plan.clients} clients</span>
                  </div>
                  <div className="h-2 bg-gray-100 rounded-full">
                    <div
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${(plan.employees / planMetrics.totalEmployees) * 100}%` }}
                    />
                  </div>
                </div>
                <span className="ml-4 text-sm text-gray-500">{plan.employees} employees</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Benefit Utilization</h3>
          <div className="space-y-4">
            {planMetrics.benefitUtilization.map((benefit) => (
              <div key={benefit.benefit}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm text-gray-600">{benefit.benefit}</span>
                  <span className="text-sm font-medium text-gray-900">{benefit.utilization}%</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full">
                  <div
                    className="h-full bg-purple-500 rounded-full"
                    style={{ width: `${benefit.utilization}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
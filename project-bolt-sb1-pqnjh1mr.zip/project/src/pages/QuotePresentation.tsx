import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Building, FileText, Plus, Trash2, Download, Mail, Eye, Edit3, Check, X, AlertCircle, Image as ImageIcon, Presentation } from 'lucide-react';
import pptxgen from 'pptxgenjs';

interface PlanOption {
  id: string;
  name: string;
  benefits: {
    health: {
      included: boolean;
      coverage: string;
      details: string[];
    };
    dental: {
      included: boolean;
      coverage: string;
      details: string[];
    };
    life: {
      included: boolean;
      coverage: string;
      details: string[];
    };
    ltd: {
      included: boolean;
      coverage: string;
      details: string[];
    };
    addOns: {
      name: string;
      included: boolean;
      details: string;
    }[];
  };
  costSharing: {
    employer: number;
    employee: number;
  };
  monthlyPremium: {
    total: number;
    perEmployee: number;
  };
  notes: string;
  isRecommended: boolean;
}

interface Presentation {
  id: string;
  title: string;
  clientName: string;
  clientLogo?: string;
  advisorName: string;
  advisorLogo?: string;
  createdAt: string;
  lastModified: string;
  summary: string;
  planOptions: PlanOption[];
}

const mockPresentation: Presentation = {
  id: '1',
  title: 'Tech Solutions Inc. Plan Options – May 2025',
  clientName: 'Tech Solutions Inc.',
  advisorName: 'Sarah Johnson',
  createdAt: '2024-03-20',
  lastModified: '2024-03-20',
  summary: "Based on our discussion of your team's needs and budget considerations, I've prepared three plan options for your review. Option B (Enhanced Plan) provides the best balance of comprehensive coverage and cost-effectiveness.",
  planOptions: [
    {
      id: '1',
      name: 'Option A - Basic Plan',
      benefits: {
        health: {
          included: true,
          coverage: '70%',
          details: [
            'Prescription drugs',
            'Paramedical services up to $300/practitioner',
            'Vision care $200/24 months'
          ]
        },
        dental: {
          included: true,
          coverage: '80% Basic / 50% Major',
          details: [
            'Basic services',
            'Major services $1,000 annual maximum',
            'No orthodontics'
          ]
        },
        life: {
          included: true,
          coverage: '1x Salary',
          details: [
            'Basic life insurance',
            'AD&D included',
            'No optional life'
          ]
        },
        ltd: {
          included: true,
          coverage: '60% to $3,000',
          details: [
            '119-day waiting period',
            'To age 65',
            'Non-taxable benefit'
          ]
        },
        addOns: [
          {
            name: 'EAP',
            included: true,
            details: 'Basic counseling services'
          },
          {
            name: 'HSA',
            included: false,
            details: ''
          }
        ]
      },
      costSharing: {
        employer: 75,
        employee: 25
      },
      monthlyPremium: {
        total: 12500,
        perEmployee: 275
      },
      notes: 'Entry-level plan with essential coverage',
      isRecommended: false
    },
    {
      id: '2',
      name: 'Option B - Enhanced Plan',
      benefits: {
        health: {
          included: true,
          coverage: '80%',
          details: [
            'Prescription drugs',
            'Paramedical services up to $500/practitioner',
            'Vision care $300/24 months'
          ]
        },
        dental: {
          included: true,
          coverage: '100% Basic / 60% Major',
          details: [
            'Basic services',
            'Major services $1,500 annual maximum',
            'Orthodontics 50% to $2,000 lifetime'
          ]
        },
        life: {
          included: true,
          coverage: '2x Salary',
          details: [
            'Basic life insurance',
            'AD&D included',
            'Optional life available'
          ]
        },
        ltd: {
          included: true,
          coverage: '66.67% to $5,000',
          details: [
            '119-day waiting period',
            'To age 65',
            'Non-taxable benefit'
          ]
        },
        addOns: [
          {
            name: 'EAP',
            included: true,
            details: 'Enhanced counseling and work-life services'
          },
          {
            name: 'HSA',
            included: true,
            details: '$500 annual allocation'
          }
        ]
      },
      costSharing: {
        employer: 80,
        employee: 20
      },
      monthlyPremium: {
        total: 15800,
        perEmployee: 350
      },
      notes: 'Recommended option balancing coverage and cost',
      isRecommended: true
    },
    {
      id: '3',
      name: 'Option C - Premium Plan',
      benefits: {
        health: {
          included: true,
          coverage: '90%',
          details: [
            'Prescription drugs',
            'Paramedical services up to $750/practitioner',
            'Vision care $400/24 months'
          ]
        },
        dental: {
          included: true,
          coverage: '100% Basic / 80% Major',
          details: [
            'Basic services',
            'Major services $2,000 annual maximum',
            'Orthodontics 50% to $3,000 lifetime'
          ]
        },
        life: {
          included: true,
          coverage: '3x Salary',
          details: [
            'Basic life insurance',
            'AD&D included',
            'Optional life available'
          ]
        },
        ltd: {
          included: true,
          coverage: '66.67% to $7,000',
          details: [
            '119-day waiting period',
            'To age 65',
            'Non-taxable benefit'
          ]
        },
        addOns: [
          {
            name: 'EAP',
            included: true,
            details: 'Premium counseling and wellness services'
          },
          {
            name: 'HSA',
            included: true,
            details: '$1,000 annual allocation'
          }
        ]
      },
      costSharing: {
        employer: 85,
        employee: 15
      },
      monthlyPremium: {
        total: 19800,
        perEmployee: 440
      },
      notes: 'Premium option with comprehensive coverage',
      isRecommended: false
    }
  ]
};

export default function QuotePresentation() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [presentation, setPresentation] = useState<Presentation>(mockPresentation);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState<'preview' | 'edit'>('preview');
  const [exportType, setExportType] = useState<'pdf' | 'pptx'>('pdf');
  const [showExportMenu, setShowExportMenu] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const handleExportPowerPoint = async () => {
    const pptx = new pptxgen();

    pptx.author = presentation.advisorName;
    pptx.company = "Chamber Plan";
    pptx.title = presentation.title;

    const titleSlide = pptx.addSlide();
    titleSlide.addText(presentation.title, {
      x: 0.5,
      y: 1.5,
      w: '90%',
      fontSize: 44,
      bold: true,
      color: '363B3E'
    });
    titleSlide.addText(`Prepared for ${presentation.clientName}`, {
      x: 0.5,
      y: 2.5,
      fontSize: 24,
      color: '666666'
    });
    titleSlide.addText(`By ${presentation.advisorName}`, {
      x: 0.5,
      y: 3.0,
      fontSize: 18,
      color: '666666'
    });
    titleSlide.addText(new Date().toLocaleDateString(), {
      x: 0.5,
      y: 3.5,
      fontSize: 16,
      color: '666666'
    });

    const summarySlide = pptx.addSlide();
    summarySlide.addText('Executive Summary', {
      x: 0.5,
      y: 0.5,
      fontSize: 32,
      bold: true,
      color: '363B3E'
    });
    summarySlide.addText(presentation.summary, {
      x: 0.5,
      y: 1.5,
      w: '90%',
      fontSize: 16,
      color: '666666'
    });

    presentation.planOptions.forEach((option, index) => {
      const planSlide = pptx.addSlide();
      
      planSlide.addText(option.name, {
        x: 0.5,
        y: 0.5,
        fontSize: 32,
        bold: true,
        color: '363B3E'
      });

      if (option.isRecommended) {
        planSlide.addText('★ Recommended Option', {
          x: 0.5,
          y: 1.0,
          fontSize: 16,
          color: '4A90E2',
          bold: true
        });
      }

      planSlide.addText(`Monthly Premium: ${formatCurrency(option.monthlyPremium.perEmployee)}/employee`, {
        x: 0.5,
        y: 1.5,
        fontSize: 20,
        bold: true,
        color: '363B3E'
      });

      const tableData = [
        ['Benefit Type', 'Coverage', 'Details'],
        ['Health', option.benefits.health.coverage, option.benefits.health.details.join(', ')],
        ['Dental', option.benefits.dental.coverage, option.benefits.dental.details.join(', ')],
        ['Life', option.benefits.life.coverage, option.benefits.life.details.join(', ')],
        ['LTD', option.benefits.ltd.coverage, option.benefits.ltd.details.join(', ')]
      ];

      planSlide.addTable(tableData, {
        x: 0.5,
        y: 2.0,
        w: '90%',
        columnWidth: [2, 2, 5],
        border: { pt: 1, color: 'CFCFCF' },
        color: '666666'
      });

      planSlide.addText('Cost Sharing', {
        x: 0.5,
        y: 5.0,
        fontSize: 20,
        bold: true,
        color: '363B3E'
      });

      planSlide.addText(`Employer: ${option.costSharing.employer}% | Employee: ${option.costSharing.employee}%`, {
        x: 0.5,
        y: 5.5,
        fontSize: 16,
        color: '666666'
      });
    });

    pptx.writeFile({ fileName: `${presentation.clientName} - Benefits Proposal.pptx` });
  };

  const handleExport = () => {
    if (exportType === 'pptx') {
      handleExportPowerPoint();
    } else {
      console.log('Exporting PDF...');
    }
    setShowExportMenu(false);
  };

  const handleShare = () => {
    console.log('Sharing presentation...');
  };

  const handleSave = () => {
    setIsEditing(false);
    console.log('Saving presentation...');
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate(`/quotes/${id}`)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{presentation.title}</h1>
            <p className="text-gray-500">Created {new Date(presentation.createdAt).toLocaleDateString()}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setActiveTab(activeTab === 'preview' ? 'edit' : 'preview')}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'preview'
                ? 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            {activeTab === 'preview' ? (
              <>
                <Edit3 className="h-5 w-5 mr-2" />
                Edit
              </>
            ) : (
              <>
                <Eye className="h-5 w-5 mr-2" />
                Preview
              </>
            )}
          </button>
          <button
            onClick={handleShare}
            className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Mail className="h-5 w-5 mr-2" />
            Share
          </button>
          <div className="relative">
            <button
              onClick={() => setShowExportMenu(!showExportMenu)}
              className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Download className="h-5 w-5 mr-2" />
              Export
            </button>
            {showExportMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1">
                <button
                  onClick={() => {
                    setExportType('pdf');
                    handleExport();
                  }}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  Export as PDF
                </button>
                <button
                  onClick={() => {
                    setExportType('pptx');
                    handleExport();
                  }}
                  className="flex items-center w-full px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                >
                  <Presentation className="h-4 w-4 mr-2" />
                  Export as PowerPoint
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="h-16 w-16 bg-gray-100 rounded-lg flex items-center justify-center">
                {presentation.clientLogo ? (
                  <img
                    src={presentation.clientLogo}
                    alt={presentation.clientName}
                    className="h-12 w-12 object-contain"
                  />
                ) : (
                  <Building className="h-8 w-8 text-gray-400" />
                )}
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900">{presentation.clientName}</h2>
                <p className="text-gray-500">Prepared by {presentation.advisorName}</p>
              </div>
            </div>
            {activeTab === 'edit' && (
              <button className="flex items-center text-sm text-blue-600 hover:text-blue-700">
                <ImageIcon className="h-4 w-4 mr-1" />
                Add Logo
              </button>
            )}
          </div>
        </div>

        <div className="p-6 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Executive Summary</h3>
          {activeTab === 'edit' ? (
            <textarea
              value={presentation.summary}
              onChange={(e) => setPresentation({ ...presentation, summary: e.target.value })}
              className="w-full h-32 rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
              placeholder="Enter a summary of the quote presentation..."
            />
          ) : (
            <p className="text-gray-600">{presentation.summary}</p>
          )}
        </div>

        <div className="p-6">
          <div className="grid grid-cols-3 gap-6">
            {presentation.planOptions.map((option) => (
              <div
                key={option.id}
                className={`rounded-lg border ${
                  option.isRecommended ? 'border-blue-200 bg-blue-50' : 'border-gray-200'
                }`}
              >
                <div className="p-4 border-b border-gray-200">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{option.name}</h3>
                      <p className="text-2xl font-bold text-gray-900 mt-2">
                        {formatCurrency(option.monthlyPremium.perEmployee)}
                        <span className="text-sm font-normal text-gray-500">/employee/month</span>
                      </p>
                    </div>
                    {option.isRecommended && (
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded">
                        Recommended
                      </span>
                    )}
                  </div>
                </div>

                <div className="p-4 space-y-4">
                  <div>
                    <h4 className="font-medium text-gray-900">Health Insurance</h4>
                    <p className="text-sm text-gray-600 mt-1">Coverage: {option.benefits.health.coverage}</p>
                    <ul className="mt-2 space-y-1">
                      {option.benefits.health.details.map((detail, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900">Dental Insurance</h4>
                    <p className="text-sm text-gray-600 mt-1">Coverage: {option.benefits.dental.coverage}</p>
                    <ul className="mt-2 space-y-1">
                      {option.benefits.dental.details.map((detail, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900">Life Insurance</h4>
                    <p className="text-sm text-gray-600 mt-1">Coverage: {option.benefits.life.coverage}</p>
                    <ul className="mt-2 space-y-1">
                      {option.benefits.life.details.map((detail, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900">Long Term Disability</h4>
                    <p className="text-sm text-gray-600 mt-1">Coverage: {option.benefits.ltd.coverage}</p>
                    <ul className="mt-2 space-y-1">
                      {option.benefits.ltd.details.map((detail, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          <Check className="h-4 w-4 text-green-500 mr-2" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900">Additional Benefits</h4>
                    <ul className="mt-2 space-y-1">
                      {option.benefits.addOns.map((addon, index) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          {addon.included ? (
                            <Check className="h-4 w-4 text-green-500 mr-2" />
                          ) : (
                            <X className="h-4 w-4 text-gray-400 mr-2" />
                          )}
                          <span className={addon.included ? 'text-gray-900' : 'text-gray-400'}>
                            {addon.name}
                            {addon.included && addon.details && (
                              <span className="text-gray-500"> - {addon.details}</span>
                            )}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="pt-4 border-t border-gray-200">
                    <h4 className="font-medium text-gray-900">Cost Sharing</h4>
                    <div className="mt-2 flex items-center space-x-4">
                      <div>
                        <p className="text-sm text-gray-500">Employer</p>
                        <p className="text-lg font-semibold text-gray-900">{option.costSharing.employer}%</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Employee</p>
                        <p className="text-lg font-semibold text-gray-900">{option.costSharing.employee}%</p>
                      </div>
                    </div>
                  </div>

                  {option.notes && (
                    <div className="pt-4 border-t border-gray-200">
                      <p className="text-sm text-gray-600">{option.notes}</p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
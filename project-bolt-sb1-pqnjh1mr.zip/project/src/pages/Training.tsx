import React, { useState } from 'react';
import { Book, CheckCircle, Clock, Star, Play, BarChart, Users, FileText, Shield, Calculator, Award, Brain, MessageSquare, Handshake, Building2 } from 'lucide-react';

interface Module {
  id: string;
  title: string;
  description: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  progress: number;
  icon: React.ElementType;
  sections: {
    id: string;
    title: string;
    completed: boolean;
    content: string;
    quiz?: {
      question: string;
      options: string[];
      correctAnswer: number;
    }[];
  }[];
}

const trainingModules: Module[] = [
  {
    id: '1',
    title: 'Group Benefits Fundamentals',
    description: 'Learn the basics of group benefits, including key terms, common plan designs, and core coverage types.',
    duration: '2 hours',
    level: 'Beginner',
    progress: 0,
    icon: Shield,
    sections: [
      {
        id: '1-1',
        title: 'Introduction to Group Benefits',
        completed: false,
        content: `
# Introduction to Group Benefits

Group benefits are a crucial part of employee compensation packages. This module covers:

## Key Concepts
- What are group benefits?
- Why employers offer benefits
- Key stakeholders in group benefits

## Types of Coverage
1. Health Insurance
2. Dental Coverage
3. Life Insurance
4. Disability Insurance
5. Additional Benefits

## Market Overview
- Current trends
- Canadian healthcare system interaction
- Key providers
        `,
        quiz: [
          {
            question: 'What is the primary purpose of group benefits?',
            options: [
              'To increase company profits',
              'To attract and retain employees',
              'To reduce tax burden',
              'To comply with regulations'
            ],
            correctAnswer: 1
          }
        ]
      },
      {
        id: '1-2',
        title: 'Core Coverage Types',
        completed: false,
        content: `
# Core Coverage Types

Understanding the fundamental types of coverage is essential for any benefits advisor.

## Extended Health Care
- Prescription drugs
- Paramedical services
- Vision care
- Medical supplies

## Dental Insurance
- Basic services
- Major services
- Orthodontics
- Coverage levels and limitations

## Life Insurance
- Basic life
- Optional life
- Dependent life
- AD&D coverage
        `,
        quiz: [
          {
            question: 'Which of the following is typically included in basic dental coverage?',
            options: [
              'Orthodontics',
              'Routine cleanings',
              'Dental implants',
              'Cosmetic procedures'
            ],
            correctAnswer: 1
          }
        ]
      }
    ]
  },
  {
    id: '2',
    title: 'Needs Analysis & Discovery',
    description: 'Master the art of conducting effective client discovery meetings and analyzing benefit needs.',
    duration: '1.5 hours',
    level: 'Intermediate',
    progress: 0,
    icon: Brain,
    sections: [
      {
        id: '2-1',
        title: 'Discovery Process',
        completed: false,
        content: `
# The Discovery Process

Learn how to conduct effective discovery meetings with prospects and clients.

## Key Areas to Explore
1. Company Demographics
2. Current Benefits Structure
3. Pain Points
4. Budget Considerations
5. Future Growth Plans

## Effective Questions
- Open-ended vs. closed questions
- Follow-up techniques
- Active listening skills
        `,
        quiz: [
          {
            question: 'What should be your first question in a discovery meeting?',
            options: [
              'What is your budget?',
              'Tell me about your company and its culture',
              'Are you happy with your current provider?',
              'How many employees do you have?'
            ],
            correctAnswer: 1
          }
        ]
      }
    ]
  },
  {
    id: '3',
    title: 'Plan Design & Pricing',
    description: 'Learn how to structure benefit plans and understand pricing methodologies.',
    duration: '3 hours',
    level: 'Advanced',
    progress: 0,
    icon: Calculator,
    sections: []
  },
  {
    id: '4',
    title: 'Client Relationship Management',
    description: 'Develop strong client relationships and learn effective account management strategies.',
    duration: '2 hours',
    level: 'Intermediate',
    progress: 0,
    icon: Handshake,
    sections: []
  },
  {
    id: '5',
    title: 'Chamber Relations',
    description: 'Learn how to work effectively with Chambers of Commerce and leverage partnerships.',
    duration: '1.5 hours',
    level: 'Intermediate',
    progress: 0,
    icon: Building2,
    sections: []
  }
];

export default function Training() {
  const [selectedModule, setSelectedModule] = useState<Module | null>(null);
  const [selectedSection, setSelectedSection] = useState<string | null>(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState<{ [key: string]: number }>({});
  const [showResults, setShowResults] = useState(false);

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner':
        return 'bg-green-100 text-green-800';
      case 'Intermediate':
        return 'bg-blue-100 text-blue-800';
      case 'Advanced':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleModuleSelect = (module: Module) => {
    setSelectedModule(module);
    setSelectedSection(module.sections[0]?.id || null);
    setShowQuiz(false);
    setShowResults(false);
  };

  const handleSectionSelect = (sectionId: string) => {
    setSelectedSection(sectionId);
    setShowQuiz(false);
    setShowResults(false);
  };

  const handleQuizSubmit = () => {
    setShowResults(true);
  };

  const handleAnswerSelect = (questionIndex: number, answerIndex: number) => {
    setQuizAnswers({
      ...quizAnswers,
      [`${selectedSection}-${questionIndex}`]: answerIndex
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {!selectedModule ? (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Training Center</h1>
              <p className="text-gray-500">Enhance your skills and knowledge with our interactive training modules</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-600">10 hours total</span>
              </div>
              <div className="flex items-center space-x-2">
                <Book className="h-5 w-5 text-gray-400" />
                <span className="text-sm text-gray-600">5 modules</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {trainingModules.map((module) => (
              <div
                key={module.id}
                className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => handleModuleSelect(module)}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <module.icon className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900">{module.title}</h3>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getLevelColor(module.level)}`}>
                          {module.level}
                        </span>
                      </div>
                    </div>
                    {module.progress === 100 && (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    )}
                  </div>

                  <p className="mt-4 text-sm text-gray-600">{module.description}</p>

                  <div className="mt-4 flex items-center justify-between">
                    <div className="flex items-center space-x-2 text-sm text-gray-500">
                      <Clock className="h-4 w-4" />
                      <span>{module.duration}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="bg-gray-200 h-2 w-24 rounded-full overflow-hidden">
                        <div
                          className="bg-blue-500 h-full rounded-full"
                          style={{ width: `${module.progress}%` }}
                        />
                      </div>
                      <span className="text-sm text-gray-500">{module.progress}%</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setSelectedModule(null)}
              className="text-gray-600 hover:text-gray-900"
            >
              ← Back to Modules
            </button>
            <h1 className="text-2xl font-bold text-gray-900">{selectedModule.title}</h1>
          </div>

          <div className="grid grid-cols-12 gap-6">
            <div className="col-span-3 bg-white rounded-lg shadow-sm p-4">
              <h3 className="font-semibold text-gray-900 mb-4">Module Sections</h3>
              <div className="space-y-2">
                {selectedModule.sections.map((section) => (
                  <button
                    key={section.id}
                    onClick={() => handleSectionSelect(section.id)}
                    className={`w-full text-left px-4 py-2 rounded-lg transition-colors ${
                      selectedSection === section.id
                        ? 'bg-blue-50 text-blue-700'
                        : 'hover:bg-gray-50 text-gray-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{section.title}</span>
                      {section.completed && (
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="col-span-9 bg-white rounded-lg shadow-sm p-6">
              {selectedSection && (
                <div>
                  {!showQuiz ? (
                    <div className="prose max-w-none">
                      <div dangerouslySetInnerHTML={{
                        __html: selectedModule.sections.find(s => s.id === selectedSection)?.content || ''
                      }} />
                      {selectedModule.sections.find(s => s.id === selectedSection)?.quiz && (
                        <button
                          onClick={() => setShowQuiz(true)}
                          className="mt-8 flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                          <Play className="h-5 w-5 mr-2" />
                          Take Quiz
                        </button>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-8">
                      <h2 className="text-xl font-semibold text-gray-900">Knowledge Check</h2>
                      {selectedModule.sections
                        .find(s => s.id === selectedSection)
                        ?.quiz?.map((question, qIndex) => (
                          <div key={qIndex} className="space-y-4">
                            <p className="font-medium text-gray-900">{question.question}</p>
                            <div className="space-y-2">
                              {question.options.map((option, oIndex) => (
                                <label
                                  key={oIndex}
                                  className={`flex items-center space-x-3 p-4 rounded-lg border cursor-pointer ${
                                    quizAnswers[`${selectedSection}-${qIndex}`] === oIndex
                                      ? 'border-blue-500 bg-blue-50'
                                      : 'border-gray-200 hover:bg-gray-50'
                                  }`}
                                >
                                  <input
                                    type="radio"
                                    name={`question-${qIndex}`}
                                    checked={quizAnswers[`${selectedSection}-${qIndex}`] === oIndex}
                                    onChange={() => handleAnswerSelect(qIndex, oIndex)}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                                  />
                                  <span className="text-gray-900">{option}</span>
                                  {showResults && (
                                    oIndex === question.correctAnswer ? (
                                      <CheckCircle className="h-5 w-5 text-green-500 ml-auto" />
                                    ) : quizAnswers[`${selectedSection}-${qIndex}`] === oIndex ? (
                                      <X className="h-5 w-5 text-red-500 ml-auto" />
                                    ) : null
                                  )}
                                </label>
                              ))}
                            </div>
                          </div>
                        ))}
                      {!showResults ? (
                        <button
                          onClick={handleQuizSubmit}
                          className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                        >
                          Submit Answers
                        </button>
                      ) : (
                        <button
                          onClick={() => {
                            setShowQuiz(false);
                            setShowResults(false);
                            setQuizAnswers({});
                          }}
                          className="mt-6 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
                        >
                          Return to Content
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
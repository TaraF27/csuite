import React, { useState } from 'react';
import { Search, Filter, Clock, CheckCircle, XCircle, Building2, Users, Phone, Mail, MapPin, Calendar, DollarSign, ArrowUpRight, AlertCircle, MessageSquare, FileText } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Mock data for leads and referrals
const mockData = {
  leads: [
    {
      id: '1',
      companyName: 'Tech Innovators Ltd',
      source: 'Chamber Referral',
      status: 'New',
      contactName: 'John Smith',
      contactEmail: 'john@techinnovators.com',
      contactPhone: '(604) 555-0123',
      employeeCount: 45,
      industry: 'Technology',
      location: 'Vancouver, BC',
      dateReceived: '2024-03-20',
      lastContact: '2024-03-21',
      nextFollowUp: '2024-03-25',
      notes: 'Interested in comprehensive benefits package. Currently no coverage.',
      potentialValue: 85000,
      chamberMember: true,
      priority: 'High'
    },
    {
      id: '2',
      companyName: 'Global Manufacturing Co',
      source: 'Website Inquiry',
      status: 'In Progress',
      contactName: 'Sarah Chen',
      contactEmail: 'sarah@globalmanufacturing.com',
      contactPhone: '(604) 555-0456',
      employeeCount: 78,
      industry: 'Manufacturing',
      location: 'Richmond, BC',
      dateReceived: '2024-03-18',
      lastContact: '2024-03-19',
      nextFollowUp: '2024-03-24',
      notes: 'Looking to switch providers. Current plan expires in 2 months.',
      potentialValue: 120000,
      chamberMember: false,
      priority: 'Medium'
    },
    {
      id: '3',
      companyName: 'Coastal Restaurants Inc',
      source: 'Networking Event',
      status: 'Proposal Sent',
      contactName: 'Michael Brown',
      contactEmail: 'michael@coastalrestaurants.com',
      contactPhone: '(604) 555-0789',
      employeeCount: 35,
      industry: 'Hospitality',
      location: 'North Vancouver, BC',
      dateReceived: '2024-03-15',
      lastContact: '2024-03-20',
      nextFollowUp: '2024-03-27',
      notes: 'Reviewing proposal. Main concern is cost stability.',
      potentialValue: 65000,
      chamberMember: true,
      priority: 'High'
    }
  ],
  referrals: [
    {
      id: '1',
      companyName: 'Pacific Tech Solutions',
      referredBy: 'Vancouver Chamber of Commerce',
      referralDate: '2024-03-22',
      status: 'New',
      contactInfo: {
        name: 'David Wilson',
        email: 'david@pacifictech.com',
        phone: '(604) 555-9012'
      },
      notes: 'Growing tech company, interested in comprehensive coverage',
      followUpDate: '2024-03-25'
    },
    {
      id: '2',
      companyName: 'Mountain View Consulting',
      referredBy: 'Richmond Chamber of Commerce',
      referralDate: '2024-03-21',
      status: 'Contacted',
      contactInfo: {
        name: 'Lisa Chang',
        email: 'lisa@mountainview.com',
        phone: '(604) 555-3456'
      },
      notes: 'Currently shopping for new benefits provider',
      followUpDate: '2024-03-24'
    }
  ]
};

interface Lead {
  id: string;
  companyName: string;
  source: string;
  status: string;
  contactName: string;
  contactEmail: string;
  contactPhone: string;
  employeeCount: number;
  industry: string;
  location: string;
  dateReceived: string;
  lastContact: string;
  nextFollowUp: string;
  notes: string;
  potentialValue: number;
  chamberMember: boolean;
  priority: 'High' | 'Medium' | 'Low';
}

interface Referral {
  id: string;
  companyName: string;
  referredBy: string;
  referralDate: string;
  status: string;
  contactInfo: {
    name: string;
    email: string;
    phone: string;
  };
  notes: string;
  followUpDate: string;
}

// Add summary calculation functions
const calculateSummary = (data: typeof mockData) => {
  const leads = data.leads;
  const referrals = data.referrals;

  const leadsByStatus = leads.reduce((acc, lead) => {
    acc[lead.status] = (acc[lead.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const referralsByStatus = referrals.reduce((acc, referral) => {
    acc[referral.status] = (acc[referral.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalPotentialValue = leads.reduce((sum, lead) => sum + lead.potentialValue, 0);
  const highPriorityCount = leads.filter(lead => lead.priority === 'High').length;
  const needsFollowUpCount = leads.filter(lead => 
    new Date(lead.nextFollowUp) <= new Date(new Date().setDate(new Date().getDate() + 7))
  ).length;

  return {
    totalLeads: leads.length,
    totalReferrals: referrals.length,
    leadsByStatus,
    referralsByStatus,
    totalPotentialValue,
    highPriorityCount,
    needsFollowUpCount
  };
};

export default function LeadsAndReferrals() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'leads' | 'referrals'>('leads');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [selectedReferral, setSelectedReferral] = useState<Referral | null>(null);
  const summary = calculateSummary(mockData);

  const handleConvertToQuote = (lead: Lead) => {
    const quoteData = {
      // Basic Information
      legalName: lead.companyName,
      businessNature: lead.industry,
      isIncorporated: false, // Default value, can be updated later
      operationMonths: 12, // Default value
      isNonProfit: false, // Default value

      // Contact Information
      contactName: lead.contactName,
      contactEmail: lead.contactEmail,
      contactPhone: lead.contactPhone,
      contactTitle: 'Primary Contact',

      // Address Information
      address: {
        street: '',
        city: lead.location.split(',')[0].trim(),
        province: lead.location.split(',')[1]?.trim() || '',
        postalCode: ''
      },

      // Employee Information
      employees: [{
        age: 0, // Default value
        hireDate: new Date().toISOString().split('T')[0], // Today's date
        province: lead.location.split(',')[1]?.trim() || '',
        monthlyIncome: 0,
        dependentStatus: 'None',
        jobTitle: '',
      }],

      // Coverage Interests
      coverageInterests: {
        healthInsurance: true, // Default to basic coverage options
        dentalInsurance: true,
        lifeInsurance: true,
        addInsurance: false,
        dependentLife: false,
        shortTermDisability: false,
        longTermDisability: false,
        criticalIllness: false,
        eap: false,
        hsa: false,
        lsa: false,
        virtualHealth: false,
        wellness: false,
        other: false,
        otherDetails: '',
        coveragePreferences: ''
      },

      // Additional Information
      notes: `Lead Source: ${lead.source}\nOriginal Notes: ${lead.notes}\nPriority: ${lead.priority}\nChamber Member: ${lead.chamberMember ? 'Yes' : 'No'}\nPotential Value: ${formatCurrency(lead.potentialValue)}`,

      // Metadata
      source: lead.source,
      leadId: lead.id,
      dateReceived: lead.dateReceived,
      employeeCount: lead.employeeCount,
      potentialValue: lead.potentialValue
    };

    // Store quote data in sessionStorage for the quotes page to use
    sessionStorage.setItem('newQuoteData', JSON.stringify(quoteData));
    
    // Navigate to the quotes page
    navigate('/quotes');
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'new':
        return <Clock className="h-5 w-5 text-blue-500" />;
      case 'in progress':
        return <ArrowUpRight className="h-5 w-5 text-yellow-500" />;
      case 'proposal sent':
        return <FileText className="h-5 w-5 text-purple-500" />;
      case 'contacted':
        return <MessageSquare className="h-5 w-5 text-green-500" />;
      default:
        return <AlertCircle className="h-5 w-5 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Leads and Referrals</h1>
          <p className="text-gray-500">Manage and track your leads and chamber referrals</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button className="flex items-center px-4 py-2 text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-5 w-5 mr-2" />
            Filter
          </button>
        </div>
      </div>

      {/* Add Summary Section */}
      <div className="grid grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <span className="text-sm text-gray-500">Total Opportunities</span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-gray-900">{summary.totalLeads + summary.totalReferrals}</h3>
            <div className="flex items-center space-x-2 mt-1">
              <span className="text-sm text-gray-500">{summary.totalLeads} Leads</span>
              <span className="text-gray-300">•</span>
              <span className="text-sm text-gray-500">{summary.totalReferrals} Referrals</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
            <span className="text-sm text-gray-500">Needs Follow-up</span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-gray-900">{summary.needsFollowUpCount}</h3>
            <p className="text-sm text-gray-500 mt-1">Within next 7 days</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
            <span className="text-sm text-gray-500">High Priority</span>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-gray-900">{summary.highPriorityCount}</h3>
            <p className="text-sm text-gray-500 mt-1">Leads requiring attention</p>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <div className="flex items-center justify-between">
            <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center">
              <DollarSign className="h-6 w-6 text-green-600" />
            </div>
          </div>
          <div className="mt-4">
            <h3 className="text-2xl font-bold text-gray-900">{formatCurrency(summary.totalPotentialValue)}</h3>
            <p className="text-sm text-gray-500 mt-1">Total Potential Value</p>
          </div>
        </div>
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Lead Status Distribution</h3>
          <div className="space-y-4">
            {Object.entries(summary.leadsByStatus).map(([status, count]) => (
              <div key={status}>
                <div className="flex justify-between items-center mb-1">
                  <div className="flex items-center">
                    {getStatusIcon(status)}
                    <span className="text-sm text-gray-600 ml-2">{status}</span>
                  </div>
                  <span className="text-sm font-medium text-gray-900">{count}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full">
                  <div
                    className="h-full bg-blue-500 rounded-full"
                    style={{ width: `${(count / summary.totalLeads) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Referral Status Distribution</h3>
          <div className="space-y-4">
            {Object.entries(summary.referralsByStatus).map(([status, count]) => (
              <div key={status}>
                <div className="flex justify-between items-center mb-1">
                  <div className="flex items-center">
                    {getStatusIcon(status)}
                    <span className="text-sm text-gray-600 ml-2">{status}</span>
                  </div>
                  <span className="text-sm font-medium text-gray-900">{count}</span>
                </div>
                <div className="h-2 bg-gray-100 rounded-full">
                  <div
                    className="h-full bg-purple-500 rounded-full"
                    style={{ width: `${(count / summary.totalReferrals) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('leads')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'leads'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Leads
          </button>
          <button
            onClick={() => setActiveTab('referrals')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'referrals'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Chamber Referrals
          </button>
        </nav>
      </div>

      {/* Content */}
      {activeTab === 'leads' ? (
        <div className="grid grid-cols-12 gap-6">
          {/* Leads List */}
          <div className="col-span-7">
            <div className="bg-white rounded-lg shadow">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Company
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Contact
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Follow Up
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Value
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {mockData.leads.map((lead) => (
                      <tr
                        key={lead.id}
                        onClick={() => setSelectedLead(lead)}
                        className="hover:bg-gray-50 cursor-pointer"
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <Building2 className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{lead.companyName}</div>
                              <div className="text-sm text-gray-500">{lead.industry}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            {getStatusIcon(lead.status)}
                            <span className="ml-2 text-sm text-gray-900">{lead.status}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">{lead.contactName}</div>
                          <div className="text-sm text-gray-500">{lead.contactEmail}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {formatDate(lead.nextFollowUp)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {formatCurrency(lead.potentialValue)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* Lead Details */}
          <div className="col-span-5">
            {selectedLead ? (
              <div className="bg-white rounded-lg shadow-sm p-6 space-y-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-semibold text-gray-900">{selectedLead.companyName}</h2>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getPriorityColor(selectedLead.priority)}`}>
                      {selectedLead.priority} Priority
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(selectedLead.status)}
                    <span className="text-sm font-medium text-gray-900">{selectedLead.status}</span>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Contact Information</h3>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <Users className="h-4 w-4 text-gray-400 mr-2" />
                      <span>{selectedLead.contactName}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Mail className="h-4 w-4 text-gray-400 mr-2" />
                      <a href={`mailto:${selectedLead.contactEmail}`} className="text-blue-600 hover:text-blue-800">
                        {selectedLead.contactEmail}
                      </a>
                    </div>
                    <div className="flex items-center text-sm">
                      <Phone className="h-4 w-4 text-gray-400 mr-2" />
                      <a href={`tel:${selectedLead.contactPhone}`} className="text-blue-600 hover:text-blue-800">
                        {selectedLead.contactPhone}
                      </a>
                    </div>
                    <div className="flex items-center text-sm">
                      <MapPin className="h-4 w-4 text-gray-400 mr-2" />
                      <span>{selectedLead.location}</span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Company Details</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Industry</p>
                      <p className="text-sm font-medium text-gray-900">{selectedLead.industry}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Employees</p>
                      <p className="text-sm font-medium text-gray-900">{selectedLead.employeeCount}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Potential Value</p>
                      <p className="text-sm font-medium text-gray-900">{formatCurrency(selectedLead.potentialValue)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Chamber Member</p>
                      <p className="text-sm font-medium text-gray-900">{selectedLead.chamberMember ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Important Dates</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Received</p>
                      <p className="text-sm font-medium text-gray-900">{formatDate(selectedLead.dateReceived)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Last Contact</p>
                      <p className="text-sm font-medium text-gray-900">{formatDate(selectedLead.lastContact)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Next Follow-up</p>
                      <p className="text-sm font-medium text-gray-900">{formatDate(selectedLead.nextFollowUp)}</p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-gray-200 pt-4">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Notes</h3>
                  <p className="text-sm text-gray-600">{selectedLead.notes}</p>
                </div>

                <div className="border-t border-gray-200 pt-4 flex justify-end space-x-3">
                  <button 
                    className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Edit
                  </button>
                  <button 
                    className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Schedule Follow-up
                  </button>
                  <button
                    onClick={() => handleConvertToQuote(selectedLead)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
                  >
                    <FileText className="h-4 w-4 mr-2" />
                    Convert to Quote
                  </button>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-sm p-6 text-center">
                <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No Lead Selected</h3>
                <p className="text-gray-500">Select a lead from the list to view details</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Company
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Referred By
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Contact
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Follow Up
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {mockData.referrals.map((referral) => (
                  <tr
                    key={referral.id}
                    onClick={() => setSelectedReferral(referral)}
                    className="hover:bg-gray-50 cursor-pointer"
                  >
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-purple-100 rounded-full flex items-center justify-center">
                          <Building2 className="h-5 w-5 text-purple-600" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{referral.companyName}</div>
                          <div className="text-sm text-gray-500">{formatDate(referral.referralDate)}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{referral.referredBy}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getStatusIcon(referral.status)}
                        <span className="ml-2 text-sm text-gray-900">{referral.status}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{referral.contactInfo.name}</div>
                      <div className="text-sm text-gray-500">{referral.contactInfo.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {formatDate(referral.followUpDate)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Building, Calendar, DollarSign, Users2, FileText, Clock, CheckCircle, XCircle, Shield, Mail, Phone, MapPin, Download, Printer, Presentation } from 'lucide-react';

// Mock quote data - in a real app, this would come from an API
const quoteData = {
  id: 1,
  clientName: "Tech Solutions Inc.",
  type: "Plan Upgrade",
  coverage: "Extended Health & Dental",
  requestDate: "2024-03-15",
  expiryDate: "2024-04-14",
  status: "Pending",
  value: 125000,
  employees: 45,
  contact: {
    name: "John Smith",
    email: "john@techsolutions.com",
    phone: "(555) 123-4567",
    title: "HR Director"
  },
  address: {
    street: "123 Tech Avenue",
    city: "Vancouver",
    province: "British Columbia",
    postalCode: "V6B 1A1"
  },
  coverageDetails: {
    healthInsurance: true,
    dentalInsurance: true,
    lifeInsurance: true,
    addInsurance: false,
    dependentLife: true,
    shortTermDisability: true,
    longTermDisability: true,
    criticalIllness: false,
    eap: true,
    hsa: false,
    lsa: false,
    virtualHealth: true,
    wellness: false
  },
  coveragePreferences: "80% dental coverage, $500 paramedical per practitioner",
  notes: "Client is particularly interested in comprehensive mental health support and virtual healthcare options. Current pain point is limited dental coverage.",
  history: [
    {
      date: "2024-03-15",
      action: "Quote Created",
      user: "Sarah Johnson",
      details: "Initial quote request submitted"
    },
    {
      date: "2024-03-16",
      action: "Documents Requested",
      user: "System",
      details: "Automated request for current benefits documentation"
    },
    {
      date: "2024-03-17",
      action: "Documents Received",
      user: "John Smith",
      details: "Current benefits plan documentation uploaded"
    }
  ]
};

export default function QuoteDetail() {
  const { id } = useParams();
  const navigate = useNavigate();

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'declined':
        return <XCircle className="h-5 w-5 text-red-600" />;
      default:
        return null;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/quotes')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Quote #{id}</h1>
            <p className="text-gray-500">{quoteData.clientName}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => navigate(`/quotes/${id}/presentation`)}
            className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            <Presentation className="h-5 w-5 mr-2" />
            Create Presentation
          </button>
          <button className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Printer className="h-5 w-5 mr-2" />
            Print
          </button>
          <button className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Download className="h-5 w-5 mr-2" />
            Export
          </button>
          <button className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
            Edit Quote
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Quote Overview */}
        <div className="col-span-2 bg-white rounded-lg shadow-sm p-6">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center space-x-3">
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Building className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-gray-900">{quoteData.clientName}</h2>
                <p className="text-gray-500">{quoteData.type}</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              {getStatusIcon(quoteData.status)}
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(quoteData.status)}`}>
                {quoteData.status}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <DollarSign className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-2xl font-bold text-gray-900">{formatCurrency(quoteData.value)}</p>
              <p className="text-sm text-gray-500">Total Value</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <Users2 className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-2xl font-bold text-gray-900">{quoteData.employees}</p>
              <p className="text-sm text-gray-500">Employees</p>
            </div>
            <div className="p-4 bg-gray-50 rounded-lg">
              <Calendar className="h-5 w-5 text-blue-600 mb-2" />
              <p className="text-2xl font-bold text-gray-900">{formatDate(quoteData.expiryDate)}</p>
              <p className="text-sm text-gray-500">Expiry Date</p>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact Information</h3>
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Users2 className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{quoteData.contact.name}</p>
                <p className="text-sm text-gray-500">{quoteData.contact.title}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{quoteData.contact.email}</p>
                <p className="text-sm text-gray-500">Email</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">{quoteData.contact.phone}</p>
                <p className="text-sm text-gray-500">Phone</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <MapPin className="h-5 w-5 text-gray-400" />
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {quoteData.address.street}<br />
                  {quoteData.address.city}, {quoteData.address.province}<br />
                  {quoteData.address.postalCode}
                </p>
                <p className="text-sm text-gray-500">Address</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Coverage Details & Notes */}
      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Coverage Details</h3>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(quoteData.coverageDetails).map(([key, value]) => (
              <div key={key} className="flex items-center space-x-2">
                <div className={`h-4 w-4 rounded ${value ? 'bg-blue-600' : 'bg-gray-200'}`} />
                <span className="text-sm text-gray-700">
                  {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                </span>
              </div>
            ))}
          </div>
          {quoteData.coveragePreferences && (
            <div className="mt-6">
              <h4 className="text-sm font-medium text-gray-900 mb-2">Coverage Preferences</h4>
              <p className="text-sm text-gray-600">{quoteData.coveragePreferences}</p>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Notes</h3>
          <p className="text-sm text-gray-600">{quoteData.notes}</p>
        </div>
      </div>

      {/* Quote History */}
      <div className="bg-white rounded-lg shadow-sm p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Quote History</h3>
        <div className="space-y-4">
          {quoteData.history.map((event, index) => (
            <div key={index} className="flex items-start space-x-3">
              <div className="mt-1">
                <Clock className="h-5 w-5 text-gray-400" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">{event.action}</p>
                <p className="text-sm text-gray-500">{event.details}</p>
                <p className="text-xs text-gray-400 mt-1">
                  {formatDate(event.date)} • {event.user}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
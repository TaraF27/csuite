import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Shield, Users } from 'lucide-react';

// Mock employee data - in a real app, this would come from an API
const employeeData = {
  id: 1,
  certificateNumber: "1234567890",
  firstName: "James",
  lastName: "Wilson",
  coverageType: "Family",
  effectiveDate: "2023-01-15",
  terminationDate: null,
  dateOfBirth: "1985-06-22",
  monthlySalary: 6500.00,
  email: "james.wilson@techsolutions.com",
  phone: "(555) 234-5678",
  position: "Senior Developer",
  department: "Engineering",
  dependents: [
    { name: "Sarah Wilson", relationship: "Spouse", dateOfBirth: "1987-03-15" },
    { name: "Emma Wilson", relationship: "Child", dateOfBirth: "2015-08-22" }
  ],
  coverageDetails: {
    healthDeductible: 500,
    dentalAnnualMax: 2000,
    visionCoverage: true,
    prescriptionPlan: "Extended",
    coinsurance: "80/20"
  }
};

export default function EmployeeDetail() {
  const { clientId, employeeId } = useParams();
  const navigate = useNavigate();

  const formatDate = (date: string | null) => {
    if (!date) return '-';
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate(`/crm/client/${clientId}/employees`)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">
              {employeeData.firstName} {employeeData.lastName}
            </h1>
            <p className="text-gray-500">Certificate #{employeeData.certificateNumber}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Personal Information */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <User className="h-5 w-5 text-blue-500 mr-2" />
            Personal Information
          </h2>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-500">Position</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.position}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Department</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.department}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Email</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Phone</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.phone}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Date of Birth</p>
              <p className="text-sm font-medium text-gray-900">{formatDate(employeeData.dateOfBirth)}</p>
            </div>
          </div>
        </div>

        {/* Coverage Information */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Shield className="h-5 w-5 text-blue-500 mr-2" />
            Coverage Information
          </h2>
          <div className="space-y-4">
            <div>
              <p className="text-sm text-gray-500">Coverage Type</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.coverageType}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Effective Date</p>
              <p className="text-sm font-medium text-gray-900">{formatDate(employeeData.effectiveDate)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Health Deductible</p>
              <p className="text-sm font-medium text-gray-900">{formatCurrency(employeeData.coverageDetails.healthDeductible)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Dental Annual Maximum</p>
              <p className="text-sm font-medium text-gray-900">{formatCurrency(employeeData.coverageDetails.dentalAnnualMax)}</p>
            </div>
            <div>
              <p className="text-sm text-gray-500">Coinsurance</p>
              <p className="text-sm font-medium text-gray-900">{employeeData.coverageDetails.coinsurance}</p>
            </div>
          </div>
        </div>

        {/* Dependents */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
            <Users className="h-5 w-5 text-blue-500 mr-2" />
            Dependents
          </h2>
          <div className="space-y-4">
            {employeeData.dependents.map((dependent, index) => (
              <div key={index} className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-900">{dependent.name}</p>
                <p className="text-sm text-gray-500">{dependent.relationship}</p>
                <p className="text-sm text-gray-500">Born: {formatDate(dependent.dateOfBirth)}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
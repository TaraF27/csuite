import React, { useState } from 'react';
import { Building2, Phone, Mail, Globe, Linkedin as BrandLinkedin, Twitter as BrandTwitter, Facebook as BrandFacebook, Users, DollarSign, TrendingUp, AlertCircle, FileText, Plus, Search, Filter, BarChart3, Calendar, MessageSquare, Download, Clock, CheckCircle, X } from 'lucide-react';
import MeetingScheduler from '../components/MeetingScheduler';
import RelationshipStatus from '../components/RelationshipStatus';

// Add meeting history to mock data
const chamberData = {
  chambers: [
    {
      id: '1',
      name: 'Greater Vancouver Chamber of Commerce',
      executive: {
        name: 'Jennifer Wilson',
        email: 'jwilson@gvcc.com',
        phone: '(604) 555-0123',
        title: 'Executive Director'
      },
      website: 'https://www.gvcc.com',
      social: {
        linkedin: 'https://linkedin.com/company/gvcc',
        twitter: 'https://twitter.com/gvcc',
        facebook: 'https://facebook.com/gvcc'
      },
      metrics: {
        membershipGrowth: {
          name: 'Membership Growth',
          value: 15.5,
          trend: 8.7,
          status: 'positive'
        },
        planParticipation: {
          name: 'Plan Participation',
          value: 33.5,
          trend: 12.3,
          status: 'positive'
        },
        adminFees: {
          name: 'Admin Fees YTD',
          value: 125000,
          trend: 8.7,
          status: 'positive'
        },
        memberRetention: {
          name: 'Member Retention',
          value: 93.2,
          trend: -2.1,
          status: 'negative'
        }
      },
      goals: {
        current: 285,
        target: 350,
        deadline: '2024-12-31'
      },
      alerts: [
        {
          type: 'renewal',
          message: '3 member renewals due this month',
          priority: 'medium'
        }
      ],
      nonEnrolledMembers: [
        {
          id: '1',
          name: 'Tech Innovators Ltd',
          size: 45,
          industry: 'Technology',
          potentialScore: 85
        },
        {
          id: '2',
          name: 'Pacific Manufacturing',
          size: 78,
          industry: 'Manufacturing',
          potentialScore: 92
        }
      ],
      notes: [
        {
          id: '1',
          date: '2024-03-15',
          content: 'Quarterly review meeting - discussed new member acquisition strategy',
          author: 'Sarah Johnson'
        }
      ],
      documents: [
        {
          id: '1',
          name: 'Q1 2024 Performance Review.pdf',
          type: 'pdf',
          date: '2024-03-15'
        }
      ],
      meetings: {
        upcoming: {
          date: '2024-05-15',
          time: '10:00 AM',
          location: 'Chamber Office',
          agenda: [
            'Review YTD performance',
            'Discuss member acquisition strategy',
            'Plan upcoming networking events',
            'Review benefit enhancements'
          ],
          attendees: [
            { name: 'Jennifer Wilson', role: 'Chamber Executive', email: 'jwilson@gvcc.com' },
            { name: 'Sarah Johnson', role: 'Benefits Advisor', email: 'sarah@chamberplan.ca' },
            { name: 'Michael Brown', role: 'Chamber Board Member', email: 'mbrown@gvcc.com' }
          ]
        },
        history: [
          {
            date: '2023-05-10',
            summary: '2023 Annual Partnership Review',
            outcomes: [
              'Increased member engagement by 15%',
              'Launched new wellness program',
              'Established quarterly check-ins'
            ],
            documents: [
              { name: '2023 Meeting Minutes.pdf', type: 'pdf' },
              { name: '2023-2024 Action Plan.pdf', type: 'pdf' }
            ]
          },
          {
            date: '2022-05-12',
            summary: '2022 Annual Partnership Review',
            outcomes: [
              'Set growth targets for 2023',
              'Identified key industries for expansion',
              'Reviewed communication strategy'
            ],
            documents: [
              { name: '2022 Meeting Minutes.pdf', type: 'pdf' },
              { name: '2022-2023 Strategy.pdf', type: 'pdf' }
            ]
          }
        ]
      },
      activities: [
        {
          type: 'Member Outreach',
          date: '2024-03-20',
          description: 'Contacted 5 potential new members',
          status: 'completed'
        },
        {
          type: 'Renewal Follow-up',
          date: '2024-03-18',
          description: 'Follow up on pending renewals',
          status: 'pending'
        },
        {
          type: 'Document Review',
          date: '2024-03-15',
          description: 'Annual agreement review',
          status: 'overdue'
        }
      ]
    },
    {
      id: '2',
      name: 'Richmond Chamber of Commerce',
      executive: {
        name: 'Michael Chen',
        email: 'mchen@richmondchamber.ca',
        phone: '(604) 555-0456',
        title: 'Chamber President'
      },
      website: 'https://www.richmondchamber.ca',
      social: {
        linkedin: 'https://linkedin.com/company/richmond-chamber',
        twitter: 'https://twitter.com/richmondchamber',
        facebook: 'https://facebook.com/richmondchamber'
      },
      metrics: {
        membershipGrowth: {
          name: 'Membership Growth',
          value: 12.3,
          trend: 5.2,
          status: 'positive'
        },
        planParticipation: {
          name: 'Plan Participation',
          value: 29.8,
          trend: 3.7,
          status: 'positive'
        },
        adminFees: {
          name: 'Admin Fees YTD',
          value: 85000,
          trend: 3.7,
          status: 'positive'
        },
        memberRetention: {
          name: 'Member Retention',
          value: 89.5,
          trend: -1.2,
          status: 'negative'
        }
      },
      goals: {
        current: 185,
        target: 250,
        deadline: '2024-12-31'
      },
      alerts: [
        {
          type: 'dues',
          message: '5 members in payment arrears',
          priority: 'high'
        }
      ],
      nonEnrolledMembers: [
        {
          id: '3',
          name: 'Richmond Medical Group',
          size: 35,
          industry: 'Healthcare',
          potentialScore: 78
        }
      ],
      notes: [
        {
          id: '2',
          date: '2024-03-10',
          content: 'Chamber board meeting - presented new benefits enhancement program',
          author: 'Sarah Johnson'
        }
      ],
      documents: [
        {
          id: '2',
          name: 'Member Benefits Presentation.pptx',
          type: 'pptx',
          date: '2024-03-10'
        }
      ],
      meetings: {
        upcoming: {
          date: '2024-04-20',
          time: '02:00 PM',
          location: 'Virtual Meeting',
          agenda: [
            'Review Q1 performance',
            'Discuss membership drive',
            'Plan summer events',
            'Review marketing strategy'
          ],
          attendees: [
            { name: 'Michael Chen', role: 'Chamber President', email: 'mchen@richmondchamber.ca' },
            { name: 'Sarah Johnson', role: 'Benefits Advisor', email: 'sarah@chamberplan.ca' }
          ]
        },
        history: [
          {
            date: '2023-04-15',
            summary: '2023 Annual Partnership Review',
            outcomes: [
              'Established new member benefits',
              'Created digital engagement strategy',
              'Set growth targets'
            ],
            documents: [
              { name: '2023 Meeting Minutes.pdf', type: 'pdf' },
              { name: '2023-2024 Strategy.pdf', type: 'pdf' }
            ]
          }
        ]
      },
      activities: [
        {
          type: 'Board Meeting',
          date: '2024-03-10',
          description: 'Presented benefits enhancement program',
          status: 'completed'
        },
        {
          type: 'Member Survey',
          date: '2024-03-08',
          description: 'Annual satisfaction survey',
          status: 'pending'
        }
      ]
    }
  ]
};

export default function ChamberRelations() {
  const [selectedChamber, setSelectedChamber] = useState(chamberData.chambers[0]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddNote, setShowAddNote] = useState(false);
  const [newNote, setNewNote] = useState('');
  const [showMeetingModal, setShowMeetingModal] = useState(false);
  const [showMeetingHistory, setShowMeetingHistory] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleAddNote = () => {
    if (newNote.trim()) {
      const note = {
        id: Date.now().toString(),
        date: new Date().toISOString().split('T')[0],
        content: newNote,
        author: 'Sarah Johnson'
      };
      setSelectedChamber({
        ...selectedChamber,
        notes: [note, ...selectedChamber.notes]
      });
      setNewNote('');
      setShowAddNote(false);
    }
  };

  const handleScheduleMeeting = (meetingDetails: any) => {
    console.log('Scheduling meeting:', meetingDetails);
    // Here you would typically update the chamber data with the new meeting
    setSelectedChamber({
      ...selectedChamber,
      meetings: {
        ...selectedChamber.meetings,
        upcoming: meetingDetails
      }
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Chamber Relations</h1>
          <p className="text-gray-500">Manage and grow your Chamber partnerships</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search chambers..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <button className="flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
            <Filter className="h-5 w-5 mr-2" />
            Filter
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-3 space-y-4">
          {chamberData.chambers.map((chamber) => (
            <div
              key={chamber.id}
              onClick={() => setSelectedChamber(chamber)}
              className={`bg-white rounded-lg shadow-sm p-4 cursor-pointer transition-colors ${
                selectedChamber.id === chamber.id ? 'ring-2 ring-blue-500' : 'hover:bg-gray-50'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Building2 className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">{chamber.name}</h3>
                  <p className="text-sm text-gray-500">{chamber.metrics.planParticipation.value}% participation</p>
                </div>
              </div>
              {chamber.alerts.length > 0 && (
                <div className="mt-3 flex items-center space-x-2 text-sm">
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                  <span className="text-yellow-700">{chamber.alerts.length} alerts</span>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="col-span-9 space-y-6">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex justify-between">
              <div className="flex items-start space-x-4">
                <div className="h-16 w-16 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Building2 className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-gray-900">{selectedChamber.name}</h2>
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Users className="h-4 w-4" />
                      <span>{selectedChamber.executive.name}</span>
                      <span className="text-gray-400">•</span>
                      <span className="text-gray-500">{selectedChamber.executive.title}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Mail className="h-4 w-4" />
                      <a href={`mailto:${selectedChamber.executive.email}`} className="hover:text-blue-600">
                        {selectedChamber.executive.email}
                      </a>
                    </div>
                    <div className="flex items-center space-x-2 text-gray-600">
                      <Phone className="h-4 w-4" />
                      <a href={`tel:${selectedChamber.executive.phone}`} className="hover:text-blue-600">
                        {selectedChamber.executive.phone}
                      </a>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center space-x-4">
                    <a
                      href={selectedChamber.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-500 hover:text-gray-700"
                    >
                      <Globe className="h-5 w-5" />
                    </a>
                    {Object.entries(selectedChamber.social).map(([platform, url]) => (
                      <a
                        key={platform}
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-500 hover:text-gray-700"
                      >
                        {platform === 'linkedin' && <BrandLinkedin className="h-5 w-5" />}
                        {platform === 'twitter' && <BrandTwitter className="h-5 w-5" />}
                        {platform === 'facebook' && <BrandFacebook className="h-5 w-5" />}
                      </a>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={() => setShowMeetingModal(true)}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <Calendar className="h-5 w-5 mr-2" />
                  Annual Partner Meeting
                </button>
                <button className="flex items-center px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Send Message
                </button>
              </div>
            </div>
          </div>

          {/* Relationship Status Component */}
          <RelationshipStatus
            metrics={selectedChamber.metrics}
            activities={selectedChamber.activities}
            goals={selectedChamber.goals}
          />

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Alerts & Actions</h3>
              <div className="space-y-4">
                {selectedChamber.alerts.map((alert, index) => (
                  <div
                    key={index}
                    className={`p-4 rounded-lg ${
                      alert.priority === 'high' ? 'bg-red-50' : 'bg-yellow-50'
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <AlertCircle className={`h-5 w-5 ${
                        alert.priority === 'high' ? 'text-red-500' : 'text-yellow-500'
                      }`} />
                      <div>
                        <p className={`text-sm font-medium ${
                          alert.priority === 'high' ? 'text-red-800' : 'text-yellow-800'
                        }`}>
                          {alert.message}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">High-Potential Opportunities</h3>
              <div className="space-y-4">
                {selectedChamber.nonEnrolledMembers
                  .sort((a, b) => b.potentialScore - a.potentialScore)
                  .map((member) => (
                    <div key={member.id} className="p-4 bg-gray-50 rounded-lg">
                      <div className="flex justify-between items-start">
                        <div>
                          <h4 className="text-sm font-medium text-gray-900">{member.name}</h4>
                          <p className="text-sm text-gray-500">{member.industry} • {member.size} employees</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-medium text-blue-600">{member.potentialScore}%</span>
                          <div className="h-2 w-16 bg-gray-200 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-blue-600 rounded-full"
                              style={{ width: `${member.potentialScore}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Notes & Updates</h3>
                <button
                  onClick={() => setShowAddNote(true)}
                  className="text-blue-600 hover:text-blue-700"
                >
                  <Plus className="h-5 w-5" />
                </button>
              </div>
              {showAddNote && (
                <div className="mb-4">
                  <textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Enter your note..."
                    className="w-full h-24 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  />
                  <div className="flex justify-end space-x-3 mt-2">
                    <button
                      onClick={() => setShowAddNote(false)}
                      className="px-3 py-1 text-gray-600 hover:text-gray-800"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleAddNote}
                      className="px-3 py-1 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      Add Note
                    </button>
                  </div>
                </div>
              )}
              <div className="space-y-4">
                {selectedChamber.notes.map((note) => (
                  <div key={note.id} className="p-4 bg-gray-50 rounded-lg">
                    <p className="text-sm text-gray-600">{note.content}</p>
                    <div className="mt-2 flex items-center space-x-2 text-xs text-gray-500">
                      <span>{note.author}</span>
                      <span>•</span>
                      <span>{formatDate(note.date)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Documents</h3>
              <div className="space-y-2">
                {selectedChamber.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
                  >
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-gray-400" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{doc.name}</p>
                        <p className="text-xs text-gray-500">{formatDate(doc.date)}</p>
                      </div>
                    </div>
                    <button className="text-gray-400 hover:text-gray-600">
                      <Download className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Meeting Scheduler Modal */}
      <MeetingScheduler
        isOpen={showMeetingModal}
        onClose={() => setShowMeetingModal(false)}
        onSchedule={handleScheduleMeeting}
        defaultAttendees={selectedChamber.meetings?.upcoming?.attendees || []}
      />
    </div>
  );
}
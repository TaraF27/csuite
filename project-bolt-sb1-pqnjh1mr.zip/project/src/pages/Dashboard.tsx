import React, { useState, useEffect } from 'react';
import { BarChart3, GripHorizontal, Settings, X, PieChart, Calendar, Bell, Activity, CheckSquare } from 'lucide-react';

// Widget types and their default positions
interface Widget {
  id: string;
  type: 'stats' | 'activity' | 'tasks' | 'calendar' | 'notifications' | 'performance';
  position: number;
  visible: boolean;
  title: string;
  description: string;
  icon: React.ElementType;
}

interface WidgetProps {
  id: string;
  onDragStart: (e: React.DragEvent, widgetId: string) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent, widgetId: string) => void;
}

// Available widgets configuration
const availableWidgets: Widget[] = [
  {
    id: 'stats',
    type: 'stats',
    position: 0,
    visible: true,
    title: 'Statistics',
    description: 'Overview of key metrics and performance indicators',
    icon: BarChart3
  },
  {
    id: 'activity',
    type: 'activity',
    position: 1,
    visible: true,
    title: 'Recent Activity',
    description: 'Latest updates and interactions with clients',
    icon: Activity
  },
  {
    id: 'tasks',
    type: 'tasks',
    position: 2,
    visible: true,
    title: 'Tasks',
    description: 'Your current to-do list and pending actions',
    icon: CheckSquare
  },
  {
    id: 'calendar',
    type: 'calendar',
    position: 3,
    visible: false,
    title: 'Calendar',
    description: 'Upcoming meetings and important dates',
    icon: Calendar
  },
  {
    id: 'notifications',
    type: 'notifications',
    position: 4,
    visible: false,
    title: 'Notifications',
    description: 'Important alerts and system notifications',
    icon: Bell
  },
  {
    id: 'performance',
    type: 'performance',
    position: 5,
    visible: false,
    title: 'Performance',
    description: 'Detailed metrics and analytics dashboard',
    icon: PieChart
  },
];

// Placeholder stats data
const stats = [
  { name: 'Active Clients', value: '156' },
  { name: 'Pending Quotes', value: '12' },
  { name: 'Upcoming Renewals', value: '8' },
  { name: 'New Leads', value: '24' },
];

// Settings Modal Component
const SettingsModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  widgets: Widget[];
  onWidgetToggle: (widgetId: string) => void;
}> = ({ isOpen, onClose, widgets, onWidgetToggle }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Dashboard Settings</h3>
          <button 
            onClick={onClose} 
            className="text-gray-400 hover:text-gray-600"
            aria-label="Close settings"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="space-y-4">
          <p className="text-sm text-gray-500">Select widgets to display on your dashboard</p>
          {widgets.map((widget) => (
            <div key={widget.id} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
              <div className="flex-shrink-0 mt-1">
                <widget.icon className="h-5 w-5 text-gray-500" />
              </div>
              <div className="flex-grow">
                <label 
                  htmlFor={`widget-${widget.id}`}
                  className="flex flex-col cursor-pointer"
                >
                  <span className="text-sm font-medium text-gray-900">{widget.title}</span>
                  <span className="text-xs text-gray-500 mt-1">{widget.description}</span>
                </label>
              </div>
              <div className="flex-shrink-0">
                <label className="relative inline-flex items-center">
                  <input
                    id={`widget-${widget.id}`}
                    type="checkbox"
                    checked={widget.visible}
                    onChange={() => onWidgetToggle(widget.id)}
                    className="sr-only peer"
                    aria-label={`Toggle ${widget.title} widget`}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};

const Dashboard: React.FC = () => {
  const [widgets, setWidgets] = useState<Widget[]>(availableWidgets);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const handleDragStart = (e: React.DragEvent, widgetId: string) => {
    e.dataTransfer.setData('widgetId', widgetId);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetId: string) => {
    e.preventDefault();
    const draggedId = e.dataTransfer.getData('widgetId');
    
    if (draggedId === targetId) return;

    setWidgets(prevWidgets => {
      const newWidgets = [...prevWidgets];
      const draggedIndex = newWidgets.findIndex(w => w.id === draggedId);
      const targetIndex = newWidgets.findIndex(w => w.id === targetId);
      
      const [draggedWidget] = newWidgets.splice(draggedIndex, 1);
      newWidgets.splice(targetIndex, 0, draggedWidget);
      
      return newWidgets.map((w, index) => ({ ...w, position: index }));
    });
  };

  const toggleWidget = (widgetId: string) => {
    setWidgets(prevWidgets =>
      prevWidgets.map(widget =>
        widget.id === widgetId
          ? { ...widget, visible: !widget.visible }
          : widget
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <Settings className="h-5 w-5 text-gray-500" />
            <span>Settings</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {widgets
            .filter(widget => widget.visible)
            .sort((a, b) => a.position - b.position)
            .map(widget => (
              <div
                key={widget.id}
                draggable
                onDragStart={(e) => handleDragStart(e, widget.id)}
                onDragOver={handleDragOver}
                onDrop={(e) => handleDrop(e, widget.id)}
                className="bg-white rounded-lg shadow-sm p-6 cursor-move relative group"
              >
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <GripHorizontal className="h-5 w-5 text-gray-400" />
                </div>
                <div className="flex items-center space-x-3 mb-4">
                  <widget.icon className="h-6 w-6 text-blue-500" />
                  <h2 className="text-lg font-semibold text-gray-900">{widget.title}</h2>
                </div>
                
                {/* Widget content based on type */}
                {widget.type === 'stats' && (
                  <div className="grid grid-cols-2 gap-4">
                    {stats.map((stat, index) => (
                      <div key={index} className="text-center">
                        <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                        <div className="text-sm text-gray-500">{stat.name}</div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Add other widget type content here */}
              </div>
            ))}
        </div>
      </div>

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        widgets={widgets}
        onWidgetToggle={toggleWidget}
      />
    </div>
  );
};

export default Dashboard;
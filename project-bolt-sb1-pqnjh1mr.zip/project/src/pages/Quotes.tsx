import React, { useState } from 'react';
import { Search, Filter, Plus, Building, Calendar, DollarSign, Clock, CheckCircle, XCircle, Mail, X, Loader2, Building2, Phone, AtSign, MapPin, Briefcase, Users2, Calculator, FileText, Shield } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// Mock quotes data
const quotes = [
  {
    id: 1,
    clientName: "Tech Solutions Inc.",
    type: "Plan Upgrade",
    coverage: "Extended Health & Dental",
    requestDate: "2024-03-15",
    expiryDate: "2024-04-14",
    status: "Pending",
    value: 125000,
    employees: 45,
    contact: "John Smith"
  },
  {
    id: 2,
    clientName: "Global Logistics Ltd.",
    type: "New Business",
    coverage: "Complete Benefits Package",
    requestDate: "2024-03-10",
    expiryDate: "2024-04-09",
    status: "Approved",
    value: 250000,
    employees: 78,
    contact: "Sarah Johnson"
  },
  {
    id: 3,
    clientName: "Acme Corp",
    type: "Plan Renewal",
    coverage: "Standard Health Plan",
    requestDate: "2024-03-05",
    expiryDate: "2024-04-04",
    status: "Declined",
    value: 180000,
    employees: 120,
    contact: "Michael Brown"
  }
];

interface CoverageInterests {
  healthInsurance: boolean;
  dentalInsurance: boolean;
  lifeInsurance: boolean;
  addInsurance: boolean;
  dependentLife: boolean;
  shortTermDisability: boolean;
  longTermDisability: boolean;
  criticalIllness: boolean;
  eap: boolean;
  hsa: boolean;
  lsa: boolean;
  virtualHealth: boolean;
  wellness: boolean;
  other: boolean;
  otherDetails: string;
  coveragePreferences: string;
}

interface ProspectFormData {
  legalName: string;
  isIncorporated: boolean;
  incorporationDate: string;
  operationMonths: number;
  isNonProfit: boolean;
  businessNature: string;
  contactName: string;
  contactTitle: string;
  contactPhone: string;
  contactEmail: string;
  address: {
    street: string;
    city: string;
    province: string;
    postalCode: string;
  };
  employees: {
    name?: string;
    age: number;
    hireDate: string;
    province: string;
    monthlyIncome: number;
    annualSalary?: number;
    dependentStatus: 'Single' | 'Family' | 'None';
    jobTitle: string;
  }[];
  notes: string;
  coverageInterests: CoverageInterests;
}

const initialCoverageInterests: CoverageInterests = {
  healthInsurance: false,
  dentalInsurance: false,
  lifeInsurance: false,
  addInsurance: false,
  dependentLife: false,
  shortTermDisability: false,
  longTermDisability: false,
  criticalIllness: false,
  eap: false,
  hsa: false,
  lsa: false,
  virtualHealth: false,
  wellness: false,
  other: false,
  otherDetails: '',
  coveragePreferences: '',
};

const initialFormData: ProspectFormData = {
  legalName: '',
  isIncorporated: false,
  incorporationDate: '',
  operationMonths: 12,
  isNonProfit: false,
  businessNature: '',
  contactName: '',
  contactTitle: '',
  contactPhone: '',
  contactEmail: '',
  address: {
    street: '',
    city: '',
    province: '',
    postalCode: '',
  },
  employees: [],
  notes: '',
  coverageInterests: initialCoverageInterests,
};

const provinces = [
  'Alberta',
  'British Columbia',
  'Manitoba',
  'New Brunswick',
  'Newfoundland and Labrador',
  'Nova Scotia',
  'Ontario',
  'Prince Edward Island',
  'Quebec',
  'Saskatchewan',
];

export default function Quotes() {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isEmailFormOpen, setIsEmailFormOpen] = useState(false);
  const [prospectEmail, setProspectEmail] = useState('');
  const [formData, setFormData] = useState<ProspectFormData>(initialFormData);
  const [isSending, setIsSending] = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [currentStep, setCurrentStep] = useState(1);
  const [newQuoteData, setNewQuoteData] = useState<any>(null);
  const navigate = useNavigate();

  React.useEffect(() => {
    const storedQuoteData = sessionStorage.getItem('newQuoteData');
    if (storedQuoteData) {
      const parsedData = JSON.parse(storedQuoteData);
      setNewQuoteData(parsedData);
      
      setFormData({
        ...initialFormData,
        legalName: parsedData.legalName,
        businessNature: parsedData.businessNature,
        isIncorporated: parsedData.isIncorporated,
        operationMonths: parsedData.operationMonths,
        isNonProfit: parsedData.isNonProfit,
        contactName: parsedData.contactName,
        contactEmail: parsedData.contactEmail,
        contactPhone: parsedData.contactPhone,
        contactTitle: parsedData.contactTitle,
        address: parsedData.address,
        employees: parsedData.employees,
        notes: parsedData.notes,
        coverageInterests: parsedData.coverageInterests
      });

      setIsFormOpen(true);
      sessionStorage.removeItem('newQuoteData');
    }
  }, []);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'declined':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status.toLowerCase()) {
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'declined':
        return <XCircle className="h-4 w-4 text-red-600" />;
      default:
        return null;
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const handleAddEmployee = () => {
    setFormData(prev => ({
      ...prev,
      employees: [...prev.employees, {
        age: 0,
        hireDate: '',
        province: '',
        monthlyIncome: 0,
        dependentStatus: 'None',
        jobTitle: ''
      }]
    }));
  };

  const handleRemoveEmployee = (index: number) => {
    setFormData(prev => ({
      ...prev,
      employees: prev.employees.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    console.log('Creating quote with data:', {
      ...formData,
      originalLead: newQuoteData
    });

    setIsFormOpen(false);
    setFormData(initialFormData);
    setCurrentStep(1);
    setNewQuoteData(null);
  };

  const handleSendForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);
    setSendError(null);

    try {
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-prospect-form`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          to: prospectEmail,
          advisor: {
            name: 'Sarah Johnson',
            email: 'sarah.johnson@chamberplan.ca',
          },
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to send form');
      }

      const result = await response.json();
      alert('Form has been sent to the prospect successfully!');
      setIsEmailFormOpen(false);
      setProspectEmail('');
    } catch (error) {
      setSendError(error.message);
    } finally {
      setIsSending(false);
    }
  };

  const totalSteps = 5;

  const renderStepIndicator = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between">
        {[1, 2, 3, 4, 5].map((step) => (
          <div key={step} className="flex flex-col items-center flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-2 ${
              step === currentStep
                ? 'bg-blue-600 text-white'
                : step < currentStep
                ? 'bg-green-500 text-white'
                : 'bg-gray-200 text-gray-600'
            }`}>
              {step < currentStep ? <CheckCircle className="w-5 h-5" /> : step}
            </div>
            <div className="text-sm text-gray-600">
              {step === 1 && 'Business Info'}
              {step === 2 && 'Contact Details'}
              {step === 3 && 'Employees'}
              {step === 4 && 'Coverage'}
              {step === 5 && 'Notes'}
            </div>
            {step < 5 && (
              <div className={`h-1 w-full mt-2 ${
                step < currentStep ? 'bg-green-500' : 'bg-gray-200'
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Quotes</h1>
        <div className="flex space-x-4">
          <button
            onClick={() => setIsEmailFormOpen(true)}
            className="flex items-center px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
          >
            <Mail className="h-5 w-5 mr-2" />
            Send Form to Prospect
          </button>
          <button
            onClick={() => setIsFormOpen(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="h-5 w-5 mr-2" />
            New Quote
          </button>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex justify-between items-center">
        <div className="flex-1 max-w-lg">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search quotes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <button className="flex items-center px-4 py-2 text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 ml-4">
          <Filter className="h-5 w-5 mr-2" />
          Filter
        </button>
      </div>

      {/* Quotes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quotes.map((quote) => (
          <div
            key={quote.id}
            className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow cursor-pointer"
            onClick={() => navigate(`/quotes/${quote.id}`)}
          >
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center space-x-3">
                <div className="h-10 w-10 bg-blue-100 rounded-full flex items-center justify-center">
                  <Building className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-gray-900">{quote.clientName}</h3>
                  <p className="text-sm text-gray-500">{quote.contact}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {getStatusIcon(quote.status)}
                <span className={`px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(quote.status)}`}>
                  {quote.status}
                </span>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-500">
                <DollarSign className="h-4 w-4 mr-2" />
                <span>Quote Value: {formatCurrency(quote.value)}</span>
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Calendar className="h-4 w-4 mr-2" />
                <span>Expires: {formatDate(quote.expiryDate)}</span>
              </div>
              <div className="pt-3 border-t border-gray-100">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">{quote.type}</span>
                  <span className="text-gray-900 font-medium">{quote.coverage}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Manual Entry Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 w-full max-w-4xl max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">New Quote Request</h2>
              <button
                onClick={() => {
                  setIsFormOpen(false);
                  setCurrentStep(1);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {renderStepIndicator()}

            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Step 1: Business Information */}
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Building2 className="h-5 w-5 text-blue-600" />
                      <h3 className="text-lg font-semibold text-gray-900">Business Information</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Legal Business Name</label>
                        <input
                          type="text"
                          required
                          value={formData.legalName}
                          onChange={(e) => setFormData({...formData, legalName: e.target.value})}
                          className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Nature of Business</label>
                        <input
                          type="text"
                          required
                          value={formData.businessNature}
                          onChange={(e) => setFormData({...formData, businessNature: e.target.value})}
                          className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Incorporation Status</label>
                        <div className="space-y-3">
                          <label className="flex items-center space-x-3">
                            <input
                              type="checkbox"
                              checked={formData.isIncorporated}
                              onChange={(e) => setFormData({...formData, isIncorporated: e.target.checked})}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-sm text-gray-700">Incorporated</span>
                          </label>
                          {formData.isIncorporated && (
                            <div>
                              <label className="block text-sm text-gray-600 mb-1">Date of Incorporation</label>
                              <input
                                type="date"
                                value={formData.incorporationDate}
                                onChange={(e) => setFormData({...formData, incorporationDate: e.target.value})}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Operation Details</label>
                        <div className="space-y-3">
                          <label className="flex items-center space-x-3">
                            <input
                              type="checkbox"
                              checked={formData.isNonProfit}
                              onChange={(e) => setFormData({...formData, isNonProfit: e.target.checked})}
                              className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-sm text-gray-700">Non-Profit Organization</span>
                          </label>
                          <div>
                            <label className="block text-sm text-gray-600 mb-1">Months of Operation per Year</label>
                            <input
                              type="number"
                              min="1"
                              max="12"
                              value={formData.operationMonths}
                              onChange={(e) => setFormData({...formData, operationMonths: parseInt(e.target.value)})}
                              className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 2: Contact Information */}
              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Users2 className="h-5 w-5 text-blue-600" />
                      <h3 className="text-lg font-semibold text-gray-900">Contact Information</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Contact Name</label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            value={formData.contactName}
                            onChange={(e) => setFormData({...formData, contactName: e.target.value})}
                            className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 pl-10"
                          />
                          <Users2 className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            value={formData.contactTitle}
                            onChange={(e) => setFormData({...formData, contactTitle: e.target.value})}
                            className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 pl-10"
                          />
                          <Briefcase className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-6 mt-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                        <div className="relative">
                          <input
                            type="tel"
                            required
                            value={formData.contactPhone}
                            onChange={(e) => setFormData({...formData, contactPhone: e.target.value})}
                            className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 pl-10"
                          />
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                        <div className="relative">
                          <input
                            type="email"
                            required
                            value={formData.contactEmail}
                            onChange={(e) => setFormData({...formData, contactEmail: e.target.value})}
                            className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 pl-10"
                          />
                          <AtSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <label className="block text-sm font-medium text-gray-700 mb-2">Business Address</label>
                      <div className="space-y-4">
                        <div className="relative">
                          <input
                            type="text"
                            placeholder="Street Address"
                            required
                            value={formData.address.street}
                            onChange={(e) => setFormData({
                              ...formData,
                              address: {...formData.address, street: e.target.value}
                            })}
                            className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500 pl-10"
                          />
                          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                        <div className="grid grid-cols-3 gap-4">
                          <input
                            type="text"
                            placeholder="City"
                            required
                            value={formData.address.city}
                            onChange={(e) => setFormData({
                              ...formData,
                              address: {...formData.address, city: e.target.value}
                            })}
                            className="rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                          />
                          <select
                            required
                            value={formData.address.province}
                            onChange={(e) => setFormData({
                              ...formData,
                              address: {...formData.address, province: e.target.value}
                            })}
                            className="rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                          >
                            <option value="">Select Province</option>
                            {provinces.map(province => (
                              <option key={province} value={province}>{province}</option>
                            ))}
                          </select>
                          <input
                            type="text"
                            placeholder="Postal Code"
                            required
                            value={formData.address.postalCode}
                            onChange={(e) => setFormData({
                              ...formData,
                              address: {...formData.address, postalCode: e.target.value}
                            })}
                            className="rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Step 3: Employee Information */}
              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="flex justify-between items-center mb-4">
                      <div className="flex items-center space-x-3">
                        <Users2 className="h-5 w-5 text-blue-600" />
                        <h3 className="text-lg font-semibold text-gray-900">Employee Information</h3>
                      </div>
                      <button
                        type="button"
                        onClick={handleAddEmployee}
                        className="flex items-center space-x-2 px-4 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Plus className="h-4 w-4" />
                        <span>Add Employee</span>
                      </button>
                    </div>

                    <div className="space-y-4">
                      {formData.employees.map((employee, index) => (
                        <div key={index} className="bg-white p-4 rounded-lg border border-gray-200 relative">
                          <button
                            type="button"
                            onClick={() => handleRemoveEmployee(index)}
                            className="absolute top-2 right-2 text-gray-400 hover:text-gray-600"
                          >
                            <X className="h-5 w-5" />
                          </button>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Name (Optional)</label>
                              <input
                                type="text"
                                value={employee.name || ''}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, name: e.target.value};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Age</label>
                              <input
                                type="number"
                                required
                                min="16"
                                max="100"
                                value={employee.age}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, age: parseInt(e.target.value)};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Hire Date</label>
                              <input
                                type="date"
                                required
                                value={employee.hireDate}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, hireDate: e.target.value};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Province</label>
                              <select
                                required
                                value={employee.province}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, province: e.target.value};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              >
                                <option value="">Select Province</option>
                                {provinces.map(province => (
                                  <option key={province} value={province}>{province}</option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">
                                <div className="flex items-center space-x-1">
                                  <Calculator className="h-4 w-4 text-gray-400" />
                                  <span>Monthly Income</span>
                                </div>
                              </label>
                              <input
                                type="number"
                                required
                                min="0"
                                step="100"
                                value={employee.monthlyIncome}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, monthlyIncome: parseInt(e.target.value)};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Annual Salary (Optional)</label>
                              <input
                                type="number"
                                min="0"
                                step="1000"
                                value={employee.annualSalary || ''}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, annualSalary: parseInt(e.target.value)};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-2 gap-4 mt-4">
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Dependent Status</label>
                              <select
                                required
                                value={employee.dependentStatus}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {
                                    ...employee,
                                    dependentStatus: e.target.value as 'Single' | 'Family' | 'None'
                                  };
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              >
                                <option value="None">None</option>
                                <option value="Single">Single</option>
                                <option value="Family">Family</option>
                              </select>
                            </div>
                            <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Job Title</label>
                              <input
                                type="text"
                                required
                                value={employee.jobTitle}
                                onChange={(e) => {
                                  const newEmployees = [...formData.employees];
                                  newEmployees[index] = {...employee, jobTitle: e.target.value};
                                  setFormData({...formData, employees: newEmployees});
                                }}
                                className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                              />
                            </div>
                          </div>
                        </div>
                      ))}

                      {formData.employees.length === 0 && (
                        <div className="text-center py-8 text-gray-500">
                          <Users2 className="h-12 w-12 mx-auto mb-3 text-gray-400" />
                          <p>No employees added yet.</p>
                          <p className="text-sm">Click the "Add Employee" button to get started.</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 4: Coverage Interests */}
              {currentStep === 4 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <Shield className="h-5 w-5 text-blue-600" />
                      <h3 className="text-lg font-semibold text-gray-900">Coverage Interests</h3>
                    </div>
                    
                    <p className="text-sm text-gray-600 mb-6">
                      Please indicate which types of group benefits coverage you are interested in receiving quotes for. 
                      Select all that apply. If you're unsure, your advisor can help you decide what's right for your team.
                    </p>

                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-x-6 gap-y-4">
                        {[
                          { id: 'healthInsurance', label: 'Health Insurance', description: 'Prescription drugs, paramedical services, vision, etc.' },
                          { id: 'dentalInsurance', label: 'Dental Insurance', description: 'Basic, major, and/or orthodontics' },
                          { id: 'lifeInsurance', label: 'Life Insurance', description: 'Basic or optional coverage for employees' },
                          { id: 'addInsurance', label: 'Accidental Death & Dismemberment (AD&D)', description: 'Additional coverage for accidents' },
                          { id: 'dependentLife', label: 'Dependent Life Insurance', description: 'Coverage for dependents' },
                          { id: 'shortTermDisability', label: 'Short-Term Disability (STD)', description: 'Income protection for short-term disabilities' },
                          { id: 'longTermDisability', label: 'Long-Term Disability (LTD)', description: 'Income protection for long-term disabilities' },
                          { id: 'criticalIllness', label: 'Critical Illness Insurance', description: 'Coverage for serious illnesses' },
                          { id: 'eap', label: 'Employee Assistance Program (EAP)', description: 'Mental health support and counseling' },
                          { id: 'hsa', label: 'Health Spending Account (HSA)', description: 'Flexible health care spending' },
                          { id: 'lsa', label: 'Lifestyle Spending Account (LSA)', description: 'Flexible lifestyle benefits' },
                          { id: 'virtualHealth', label: 'Virtual Health Services', description: 'Online healthcare access' },
                          { id: 'wellness', label: 'Wellness Program Add-ons', description: 'Health and wellness initiatives' },
                        ].map(({ id, label, description }) => (
                          <div key={id} className="relative flex items-start">
                            <div className="flex items-center h-6">
                              <input
                                id={id}
                                type="checkbox"
                                checked={formData.coverageInterests[id as keyof CoverageInterests] as boolean}
                                onChange={(e) => setFormData({
                                  ...formData,
                                  coverageInterests: {
                                    ...formData.coverageInterests,
                                    [id]: e.target.checked
                                  }
                                })}
                                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                              />
                            </div>
                            <div className="ml-3">
                              <label htmlFor={id} className="text-sm font-medium text-gray-900">{label}</label>
                              <p className="text-xs text-gray-500">{description}</p>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="mt-6">
                        <div className="relative flex items-start">
                          <div className="flex items-center h-6">
                            <input
                              id="other"
                              type="checkbox"
                              checked={formData.coverageInterests.other}
                              onChange={(e) => setFormData({
                                ...formData,
                                coverageInterests: {
                                  ...formData.coverageInterests,
                                  other: e.target.checked,
                                  otherDetails: e.target.checked ? formData.coverageInterests.otherDetails : ''
                                }
                              })}
                              className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            />
                          </div>
                          <div className="ml-3 flex-grow">
                            <label htmlFor="other" className="text-sm font-medium text-gray-900">Other (please specify)</label>
                            {formData.coverageInterests.other && (
                              <input
                                type="text"
                                value={formData.coverageInterests.otherDetails}
                                onChange={(e) => setFormData({
                                  ...formData,
                                  coverageInterests: {
                                    ...formData.coverageInterests,
                                    otherDetails: e.target.value
                                  }
                                })}
                                className="mt-2 block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                                placeholder="Please specify other coverage interests..."
                              />
                            )}
                          </div>
                        </div>
                      </div>

                      {Object.values(formData.coverageInterests).some(value => value === true) && (
                        <div className="mt-6">
                          <label htmlFor="coveragePreferences" className="block text-sm font-medium text-gray-900 mb-2">
                            Do you have any specific preferences or coverage levels you'd like to see?
                          </label>
                          <textarea
                            id="coveragePreferences"
                            value={formData.coverageInterests.coveragePreferences}
                            onChange={(e) => setFormData({
                              ...formData,
                              coverageInterests: {
                                ...formData.coverageInterests,
                                coveragePreferences: e.target.value
                              }
                            })}
                            rows={4}
                            className="block w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                            placeholder="e.g., 80% dental, $500 mental health, etc."
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Step 5: Notes */}
              {currentStep === 5 && (
                <div className="space-y-6">
                  <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                    <div className="flex items-center space-x-3 mb-4">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <h3 className="text-lg font-semibold text-gray-900">Additional Notes</h3>
                    </div>
                    <div>
                      <textarea
                        rows={6}
                        value={formData.notes}
                        onChange={(e) => setFormData({...formData, notes: e.target.value})}
                        placeholder="Enter any additional notes, special requirements, or important details about this quote request..."
                        className="w-full rounded-lg border-gray-300 focus:border-blue-500 focus:ring-blue-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-between pt-6">
                <button
                  type="button"
                  onClick={() => {
                    if (currentStep > 1) {
                      setCurrentStep(currentStep - 1);
                    }
                  }}
                  className={`px-6 py-2 rounded-lg transition-colors ${
                    currentStep === 1
                      ? 'invisible'
                      : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  Previous
                </button>
                <button
                  type={currentStep === totalSteps ? 'submit' : 'button'}
                  onClick={() => {
                    if (currentStep < totalSteps) {
                      setCurrentStep(currentStep + 1);
                    }
                  }}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {currentStep === totalSteps ? 'Create Quote' : 'Next'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Email Form Modal */}
      {isEmailFormOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-gray-900">Send Form to Prospect</h2>
              <button
                onClick={() => {
                  setIsEmailFormOpen(false);
                  setSendError(null);
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleSendForm} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">Prospect's Email Address</label>
                <input
                  type="email"
                  required
                  value={prospectEmail}
                  onChange={(e) => setProspectEmail(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
                  placeholder="email@example.com"
                  disabled={isSending}
                />
              </div>

              {sendError && (
                <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
                  {sendError}
                </div>
              )}

              <div className="flex justify-end space-x-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsEmailFormOpen(false);
                    setSendError(null);
                  }}
                  className="px-4 py-2 text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
                  disabled={isSending}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
                  disabled={isSending}
                >
                  {isSending ? (
                    <>
                      <Loader2 className="h-5 w-5 mr-2 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    'Send Form'
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}